export const questions = [
  // BLOCO 1 - REFLEXÃO (questões 1-10)
  {
    id: 1,
    block: "reflexao",
    text: "Antes de tomar uma decisão importante, eu costumo me retirar para um lugar tranquilo para pensar"
  },
  {
    id: 2,
    block: "reflexao",
    text: "Eu procuro ouvir diferentes pontos de vista antes de formar minha opinião"
  },
  {
    id: 3,
    block: "reflexao",
    text: "Eu costumo analisar as possíveis consequências a longo prazo das minhas decisões"
  },
  {
    id: 4,
    block: "reflexao",
    text: "Eu reservo tempo regularmente para refletir sobre minhas experiências e aprendizados"
  },
  {
    id: 5,
    block: "reflexao",
    text: "Quando enfrento um problema complexo, eu procuro entendê-lo por completo antes de agir"
  },
  {
    id: 6,
    block: "reflexao",
    text: "Eu costumo consultar fontes confiáveis antes de tomar decisões importantes"
  },
  {
    id: 7,
    block: "reflexao",
    text: "Eu pratico a escuta ativa quando alguém está compartilhando uma perspectiva diferente"
  },
  {
    id: 8,
    block: "reflexao",
    text: "Eu costumo fazer pausas conscientes durante o dia para avaliar minhas prioridades"
  },
  {
    id: 9,
    block: "reflexao",
    text: "Eu reflito sobre meus valores e princípios antes de tomar decisões significativas"
  },
  {
    id: 10,
    block: "reflexao",
    text: "Eu costumo manter um diário ou registro para organizar meus pensamentos"
  },

  // BLOCO 2 - JUÍZO (questões 11-20)
  {
    id: 11,
    block: "juizo",
    text: "Eu consigo identificar o que é essencial versus o que é secundário em uma situação"
  },
  {
    id: 12,
    block: "juizo",
    text: "Eu costumo avaliar a credibilidade das informações antes de aceitá-las como verdade"
  },
  {
    id: 13,
    block: "juizo",
    text: "Eu consigo reconhecer meus pontos cegos e preconceitos quando estou tomando decisões"
  },
  {
    id: 14,
    block: "juizo",
    text: "Eu procuro usar critérios objetivos e consistentes para minhas avaliações"
  },
  {
    id: 15,
    block: "juizo",
    text: "Eu costumo questionar minhas próprias suposições e crenças"
  },
  {
    id: 16,
    block: "juizo",
    text: "Eu consigo discernir entre emoções passageiras e intuições fundamentadas"
  },
  {
    id: 17,
    block: "juizo",
    text: "Eu procuro entender o contexto completo antes de fazer julgamentos"
  },
  {
    id: 18,
    block: "juizo",
    text: "Eu costumo buscar o conselho de pessoas sábias quando preciso formar um juízo"
  },
  {
    id: 19,
    block: "juizo",
    text: "Eu consigo reconhecer quando não tenho informações suficientes para decidir"
  },
  {
    id: 20,
    block: "juizo",
    text: "Eu procuro equilibrar a razão e a intuição em minhas avaliações"
  },

  // BLOCO 3 - DECISÃO (questões 21-30)
  {
    id: 21,
    block: "decisao",
    text: "Depois de tomar uma decisão, eu me comprometo com ela e coloco em ação"
  },
  {
    id: 22,
    block: "decisao",
    text: "Eu assumo responsabilidade pelas consequências das minhas decisões"
  },
  {
    id: 23,
    block: "decisao",
    text: "Eu costumo agir com firmeza quando estou convencido do que é certo"
  },
  {
    id: 24,
    block: "decisao",
    text: "Eu consigo tomar decisões difíceis mesmo sob pressão"
  },
  {
    id: 25,
    block: "decisao",
    text: "Eu ajusto meu curso de ação quando percebo que a decisão inicial não foi a melhor"
  },
  {
    id: 26,
    block: "decisao",
    text: " Eu comunico minhas decisões de forma clara para as pessoas afetadas"
  },
  {
    id: 27,
    block: "decisao",
    text: "Eu persisto em minhas decisões mesmo quando enfrento obstáculos"
  },
  {
    id: 28,
    block: "decisao",
    text: "Eu costumo estabelecer prazos e planos de ação para minhas decisões"
  },
  {
    id: 29,
    block: "decisao",
    text: "Eu procuro aprender com os resultados das minhas decisões, sejam eles positivos ou negativos"
  },
  {
    id: 30,
    block: "decisao",
    text: "Eu consigo tomar decisões práticas mesmo quando não tenho todas as informações ideais"
  }
];

export const blockInfo = {
  reflexao: {
    title: "REFLEXÃO",
    description: "Sua capacidade de observar e ponderar",
    icon: "🧠",
    color: "#8B7355"
  },
  juizo: {
    title: "JUÍZO", 
    description: "Sua capacidade de avaliar com clareza",
    icon: "⚖️",
    color: "#A0956B"
  },
  decisao: {
    title: "DECISÃO",
    description: "Sua capacidade de agir com firmeza", 
    icon: "🎯",
    color: "#6B5B47"
  }
};
export interface DailyExercise {
  dia: number;
  silencio: string;
  escuta: string;
  pratica: string;
  reflexao: string;
  tempo: string;
}

export interface ActionPlan {
  foco: "reflexao" | "juizo" | "decisao";
  titulo: string;
  descricao: string;
  exercicios: DailyExercise[];
}

export const actionPlans: Record<"reflexao" | "juizo" | "decisao", ActionPlan> = {
  reflexao: {
    foco: "reflexao",
    titulo: "Foco em Reflexão",
    descricao: "Exercícios para desenvolver sua capacidade de observação, ponderação e análise profunda",
    exercicios: [
      {
        dia: 1,
        silencio: "Sente-se em silêncio por 2 minutos, observando seus pensamentos sem julgá-los",
        escuta: "Ouça ativamente uma pessoa hoje, focando apenas em entender, não em responder",
        pratica: "Escreva 3 coisas que você observou hoje que normalmente passariam despercebidas",
        reflexao: "O que foi mais difícil: ficar em silêncio, ouvir sem interromper ou observar?",
        tempo: "13 min"
      },
      {
        dia: 2,
        silencio: "Respire profundamente 10 vezes, concentrando-se apenas na sensação da respiração",
        escuta: "Ouça uma música instrumental inteira prestando atenção a cada instrumento",
        pratica: "Antes de tomar qualquer decisão, pause e pergunte: 'Quais são as opções?'",
        reflexao: "Como a pausa antes de decisões mudou suas escolhas hoje?",
        tempo: "13 min"
      },
      {
        dia: 3,
        silencio: "Observe um objeto comum por 2 minutos, notando todos os detalhes possíveis",
        escuta: "Durante uma conversa, identifique o sentimento por trás das palavras",
        pratica: "Faça uma lista de prós e contras antes de uma decisão importante",
        reflexao: "Que detalhes novos você descobriu observando atentamente?",
        tempo: "13 min"
      },
      {
        dia: 4,
        silencio: "Caminhe por 2 minutos em silêncio, observando tudo ao seu redor",
        escuta: "Ouça os sons da natureza ou ambiente por 3 minutos, identificando cada um",
        pratica: "Pesquise sobre um tema que você não conheça antes de formar uma opinião",
        reflexao: "Como a pesquisa prévia mudou sua perspectiva sobre o tema?",
        tempo: "13 min"
      },
      {
        dia: 5,
        silencio: "Feche os olhos e visualize um lugar tranquilo por 2 minutos",
        escuta: "Ouça um podcast ou vídeo educativo sobre um tema novo para você",
        pratica: "Escreva sobre uma experiência passada e o que você aprendeu com ela",
        reflexao: "Que aprendizado surgiu da reflexão sobre sua experiência?",
        tempo: "13 min"
      },
      {
        dia: 6,
        silencio: "Pratique meditação guiada de 2 minutos focada na atenção plena",
        escuta: "Converse com alguém de uma geração diferente e ouça suas histórias",
        pratica: "Analise um problema complexo dividindo-o em partes menores",
        reflexao: "Como dividir o problema em partes ajudou na sua compreensão?",
        tempo: "13 min"
      },
      {
        dia: 7,
        silencio: "Observe suas emoções por 2 minutos sem tentar mudá-las",
        escuta: "Leia um artigo de opinião contrário à sua e tente entender os argumentos",
        pratica: "Crie um mapa mental com suas ideias sobre um tema importante",
        reflexao: "O que você aprendeu ao tentar entender uma perspectiva diferente?",
        tempo: "13 min"
      },
      {
        dia: 8,
        silencio: "Contemple uma paisagem ou imagem por 2 minutos em silêncio",
        escuta: "Ouça ativamente uma criança ou idoso sem interromper",
        pratica: "Antes de reagir a uma situação, conte até 10 e observe seus sentimentos",
        reflexao: "Como a pausa de 10 segundos mudou suas reações hoje?",
        tempo: "13 min"
      },
      {
        dia: 9,
        silencio: "Pratique respiração alternada (nostril yoga) por 2 minutos",
        escuta: "Assista a um documentário sobre um tema desconhecido",
        pratica: "Escreva sobre como você costuma tomar decisões e seu processo atual",
        reflexao: "Quais padrões você identificou em seu processo de decisão?",
        tempo: "13 min"
      },
      {
        dia: 10,
        silencio: "Sente-se em silêncio observando seus pensamentos como nuvens passando",
        escuta: "Participe de uma discussão ouvindo mais do que falando",
        pratica: "Analise as consequências a longo prazo de uma decisão recente",
        reflexao: "Como considerar o longo prazo mudou sua perspectiva?",
        tempo: "13 min"
      },
      {
        dia: 11,
        silencio: "Pratique scan corporal por 2 minutos, observando cada parte do corpo",
        escuta: "Ouça uma música em outro idioma e tente sentir as emoções transmitidas",
        pratica: "Crie um diário de bordo para registrar suas observações diárias",
        reflexao: "O que você descobriu sobre si mesmo ao registrar suas observações?",
        tempo: "13 min"
      },
      {
        dia: 12,
        silencio: "Contemple uma vela ou chama por 2 minutos, focando na luz e movimento",
        escuta: "Converse com alguém sobre seus sonhos e ouça com atenção genuína",
        pratica: "Pesquise diferentes pontos de vista sobre um tema controverso",
        reflexao: "Como conhecer diferentes perspectivas enriqueceu sua visão?",
        tempo: "13 min"
      },
      {
        dia: 13,
        silencio: "Pratique meditação caminhando por 2 minutos, focando nos passos",
        escuta: "Ouça uma palestra sobre filosofia ou pensamento crítico",
        pratica: "Analise um erro passado identificando o que poderia ser diferente",
        reflexao: "Que lições valiosas surgiram da análise do erro passado?",
        tempo: "13 min"
      },
      {
        dia: 14,
        silencio: "Observe o nascer ou pôr do sol por 2 minutos em silêncio",
        escuta: "Ouça ativamente seus próprios pensamentos sem julgá-los",
        pratica: "Crie um plano de ação para desenvolver um hábito de reflexão diária",
        reflexao: "Como você pode manter o hábito de reflexão após os 15 dias?",
        tempo: "13 min"
      },
      {
        dia: 15,
        silencio: "Sente-se em gratidão por 2 minutos, refletindo sobre sua jornada",
        escuta: "Compartilhe seus aprendizados com alguém e ouça seus comentários",
        pratica: "Escreva um compromisso pessoal para continuar desenvolvendo sua reflexão",
        reflexao: "Qual foi a transformação mais significativa nestes 15 dias?",
        tempo: "13 min"
      }
    ]
  },
  juizo: {
    foco: "juizo",
    titulo: "Foco em Juízo",
    descricao: "Exercícios para desenvolver sua capacidade de discernimento, análise crítica e tomada de decisão fundamentada",
    exercicios: [
      {
        dia: 1,
        silencio: "Respire profundamente e observe seus critérios de julgamento por 2 minutos",
        escuta: "Ouça diferentes opiniões sobre um tema e identifique os argumentos sólidos",
        pratica: "Analise uma notícia verificando a fonte e possíveis vieses",
        reflexao: "Quais critérios você usa para distinguir informação confiável?",
        tempo: "13 min"
      },
      {
        dia: 2,
        silencio: "Observe seus preconceitos e vieses por 2 minutos sem julgá-los",
        escuta: "Ouça um debate e identifique falácias nos argumentos",
        pratica: "Pesquise sobre vieses cognitivos e como identificá-los",
        reflexao: "Quais vieses você identificou em si mesmo hoje?",
        tempo: "13 min"
      },
      {
        dia: 3,
        silencio: "Contemple o conceito de 'verdade' por 2 minutos",
        escuta: "Ouça alguém explicar um ponto de vista contrário ao seu com mente aberta",
        pratica: "Crie uma lista de critérios para avaliar a qualidade de informações",
        reflexao: "Como seus critérios de avaliação evoluíram hoje?",
        tempo: "13 min"
      },
      {
        dia: 4,
        silencio: "Observe como você forma opiniões por 2 minutos",
        escuta: "Ouça especialistas em áreas diferentes sobre o mesmo tema",
        pratica: "Analise uma decisão passada usando seus novos critérios",
        reflexao: "Como a análise crítica mudou sua visão de decisões passadas?",
        tempo: "13 min"
      },
      {
        dia: 5,
        silencio: "Reflexione sobre a diferença entre fato e opinião por 2 minutos",
        escuta: "Ouça um podcast sobre pensamento crítico e lógica",
        pratica: "Pratique distinguir entre emoções e fatos em situações do dia a dia",
        reflexao: "Como separar emoção de fato na tomada de decisão?",
        tempo: "13 min"
      },
      {
        dia: 6,
        silencio: "Contemple a importância do contexto no julgamento por 2 minutos",
        escuta: "Ouça histórias de diferentes culturas sobre o mesmo tema",
        pratica: "Analise uma situação considerando múltiplos contextos e perspectivas",
        reflexao: "Como o contexto mudou sua compreensão da situação?",
        tempo: "13 min"
      },
      {
        dia: 7,
        silencio: "Observe seus padrões de julgamento por 2 minutos",
        escuta: "Ouça feedback sobre seus julgamentos de forma aberta",
        pratica: "Pratique fazer perguntas profundas antes de formar opiniões",
        reflexao: "Que tipo de perguntas mais ajudaram seu processo de julgamento?",
        tempo: "13 min"
      },
      {
        dia: 8,
        silencio: "Reflexione sobre equilíbrio entre razão e intuição por 2 minutos",
        escuta: "Ouça experiências de pessoas que tomam decisões intuitivamente",
        pratica: "Analise uma decisão usando tanto análise lógica quanto intuição",
        reflexao: "Como razão e intuição se complementaram em sua análise?",
        tempo: "13 min"
      },
      {
        dia: 9,
        silencio: "Contemple a ideia de 'sabedoria prática' por 2 minutos",
        escuta: "Ouça conselhos de pessoas mais experientes sobre julgamento",
        pratica: "Pratique aplicar princípios éticos em decisões pequenas",
        reflexao: "Como os princípios éticos guiaram suas decisões hoje?",
        tempo: "13 min"
      },
      {
        dia: 10,
        silencio: "Observe como você lida com incerteza por 2 minutos",
        escuta: "Ouça sobre estratégias para tomada de decisão sob incerteza",
        pratica: "Pratique tomar decisões com informações incompletas",
        reflexao: "Como você lidou com a incerteza ao tomar decisões?",
        tempo: "13 min"
      },
      {
        dia: 11,
        silencio: "Reflexione sobre a importância da humildade no julgamento por 2 minutos",
        escuta: "Ouça histórias de erros de julgamento e lições aprendidas",
        pratica: "Analise situações onde você precisou mudar de opinião",
        reflexao: "Como a humildade ajudou você a corrigir seus julgamentos?",
        tempo: "13 min"
      },
      {
        dia: 12,
        silencio: "Contemple a diferença entre julgamento e preconceito por 2 minutos",
        escuta: "Ouça perspectivas diferentes sobre justiça e equidade",
        pratica: "Pratique julgar situações baseado em méritos, não em aparências",
        reflexao: "Como você evitou preconceitos em seus julgamentos hoje?",
        tempo: "13 min"
      },
      {
        dia: 13,
        silencio: "Observe seu processo de discernimento por 2 minutos",
        escuta: "Ouça sobre filosofia do discernimento e sabedoria",
        pratica: "Crie um sistema pessoal para tomar decisões importantes",
        reflexao: "Como seu sistema de decisão funcionou na prática?",
        tempo: "13 min"
      },
      {
        dia: 14,
        silencio: "Reflexione sobre o equilíbrio entre crítica e compaixão por 2 minutos",
        escuta: "Ouça sobre a importância da empatia no julgamento",
        pratica: "Pratique dar feedback construtivo e receptivo",
        reflexao: "Como você equilibrou crítica e compaixão hoje?",
        tempo: "13 min"
      },
      {
        dia: 15,
        silencio: "Contemple sua jornada de desenvolvimento do juízo por 2 minutos",
        escuta: "Ouça seus próprios aprendizados e compartilhe com alguém",
        pratica: "Crie um plano para continuar desenvolvendo seu discernimento",
        reflexao: "Qual foi a maior transformação em sua capacidade de julgamento?",
        tempo: "13 min"
      }
    ]
  },
  decisao: {
    foco: "decisao",
    titulo: "Foco em Decisão",
    descricao: "Exercícios para desenvolver sua capacidade de ação firme, comprometimento e execução consistente",
    exercicios: [
      {
        dia: 1,
        silencio: "Respire fundo e visualize-se tomando uma decisão com confiança por 2 minutos",
        escuta: "Ouça histórias de pessoas que tomaram decisões difíceis com sucesso",
        pratica: "Tome uma pequena decisão rapidamente e comprometa-se com ela",
        reflexao: "Como se sentiu ao tomar uma decisão rápida e se comprometer?",
        tempo: "13 min"
      },
      {
        dia: 2,
        silencio: "Observe seus medos em relação a tomar decisões por 2 minutos",
        escuta: "Ouça sobre estratégias para superar o medo de errar",
        pratica: "Tome uma decisão que você vem adiando há tempo",
        reflexao: "O que o impediu de tomar essa decisão antes?",
        tempo: "13 min"
      },
      {
        dia: 3,
        silencio: "Contemple a importância do comprometimento por 2 minutos",
        escuta: "Ouça sobre a diferença entre decidir e comprometer-se",
        pratica: "Crie um plano de ação simples para uma decisão já tomada",
        reflexao: "Como o plano de ação tornou sua decisão mais concreta?",
        tempo: "13 min"
      },
      {
        dia: 4,
        silencio: "Observe sua tendência a protelar decisões por 2 minutos",
        escuta: "Ouça técnicas para combater a procrastinação na tomada de decisão",
        pratica: "Pratique a 'regra dos 2 minutos' para decisões pequenas",
        reflexao: "Como a regra dos 2 minutos afetou sua produtividade?",
        tempo: "13 min"
      },
      {
        dia: 5,
        silencio: "Reflexione sobre decisões passadas e seus resultados por 2 minutos",
        escuta: "Ouça sobre a importância de assumir responsabilidade pelas decisões",
        pratica: "Assuma responsabilidade por uma decisão recente e suas consequências",
        reflexao: "Como assumir responsabilidade mudou sua perspectiva?",
        tempo: "13 min"
      },
      {
        dia: 6,
        silencio: "Contemple a coragem necessária para decisões difíceis por 2 minutos",
        escuta: "Ouça histórias de liderança e tomada de decisão sob pressão",
        pratica: "Tome uma decisão que requer coragem, mesmo que pequena",
        reflexao: "Como você se sentiu ao tomar uma decisão corajosa?",
        tempo: "13 min"
      },
      {
        dia: 7,
        silencio: "Observe como você comunica suas decisões por 2 minutos",
        escuta: "Ouça sobre comunicação eficaz de decisões",
        pratica: "Comunique uma decisão importante de forma clara e direta",
        reflexao: "Como a comunicação clara afetou a execução da decisão?",
        tempo: "13 min"
      },
      {
        dia: 8,
        silencio: "Reflexione sobre persistência na execução por 2 minutos",
        escuta: "Ouça sobre resiliência e superação de obstáculos",
        pratica: "Continue uma ação mesmo enfrentando um pequeno obstáculo",
        reflexao: "Como você superou o obstáculo e continuou em frente?",
        tempo: "13 min"
      },
      {
        dia: 9,
        silencio: "Contemple a importância de ajustar o curso quando necessário por 2 minutos",
        escuta: "Ouça sobre flexibilidade e adaptação na tomada de decisão",
        pratica: "Reavalie e ajuste uma decisão que não está dando os resultados esperados",
        reflexao: "Como o ajuste de curso melhorou a situação?",
        tempo: "13 min"
      },
      {
        dia: 10,
        silencio: "Observe seu padrão de decisão sob pressão por 2 minutos",
        escuta: "Ouça técnicas para tomada de decisão sob pressão",
        pratica: "Pratique tomar decisões com um limite de tempo definido",
        reflexao: "Como a pressão afetou a qualidade das suas decisões?",
        tempo: "13 min"
      },
      {
        dia: 11,
        silencio: "Reflexione sobre decisões que impactam outros por 2 minutos",
        escuta: "Ouça sobre tomada de decisão considerando o bem comum",
        pratica: "Tome uma decisão considerando o impacto nas pessoas ao seu redor",
        reflexao: "Como considerar os outros mudou sua decisão?",
        tempo: "13 min"
      },
      {
        dia: 12,
        silencio: "Contemple a importância de celebrar decisões bem-sucedidas por 2 minutos",
        escuta: "Ouça sobre reconhecimento e celebração de conquistas",
        pratica: "Celebre uma decisão que levou a um resultado positivo",
        reflexao: "Como a celebração afetou sua motivação para futuras decisões?",
        tempo: "13 min"
      },
      {
        dia: 13,
        silencio: "Observe como você aprende com decisões que não deram certo por 2 minutos",
        escuta: "Ouça sobre aprendizado com falhas e fracassos",
        pratica: "Analise uma decisão que não deu certo e extraia lições",
        reflexao: "Quais lições valiosas você aprendeu com o 'fracasso'?",
        tempo: "13 min"
      },
      {
        dia: 14,
        silencio: "Reflexione sobre decisões alinhadas com seus valores por 2 minutos",
        escuta: "Ouça sobre tomada de decisão baseada em valores e princípios",
        pratica: "Tome uma decisão que reflita seus valores fundamentais",
        reflexao: "Como alinhar decisão com valores trouxe mais significado?",
        tempo: "13 min"
      },
      {
        dia: 15,
        silencio: "Contemple sua jornada de desenvolvimento decisório por 2 minutos",
        escuta: "Ouça seus próprios aprendizados e compartilhe suas conquistas",
        pratica: "Crie um compromisso para continuar desenvolvendo sua capacidade decisória",
        reflexao: "Qual foi a maior transformação em sua capacidade de decidir e agir?",
        tempo: "13 min"
      }
    ]
  }
};

// Função para determinar o foco baseado nas pontuações
export function determinarFoco(pontuacoes: { reflexao: number; juizo: number; decisao: number }): "reflexao" | "juizo" | "decisao" {
  const { reflexao, juizo, decisao } = pontuacoes;
  
  if (reflexao <= juizo && reflexao <= decisao) {
    return "reflexao";
  }
  if (juizo <= reflexao && juizo <= decisao) {
    return "juizo";
  }
  return "decisao";
}
export interface ScoreResult {
  reflexao: number;
  juizo: number;
  decisao: number;
  total: number;
}

export interface Classification {
  nivel: string;
  cor: string;
  emoji: string;
  descricao: string;
}

export interface Profile {
  id: string;
  nome: string;
  descricao: string;
  frase: string;
  cor: string;
  emoji: string;
  pontosFortes: string[];
  oportunidades: string[];
}

export interface BlockAnalysis {
  pontuacao: number;
  classificacao: Classification;
  descricao: string;
  pontosFortes: string[];
  oportunidades: string[];
  exemplo: string;
}

export interface CompleteResult {
  perfil: Profile;
  pontuacoes: ScoreResult;
  analise: {
    reflexao: BlockAnalysis;
    juizo: BlockAnalysis;
    decisao: BlockAnalysis;
  };
  nivelGeral: Classification;
}

// Classificação por pontos
export function classificarPontuacao(pontos: number): Classification {
  if (pontos >= 41) {
    return {
      nivel: "MUITO BOM",
      cor: "#8B8B47",
      emoji: "🟢",
      descricao: "Você demonstra um desenvolvimento excelente nesta área"
    };
  }
  if (pontos >= 31) {
    return {
      nivel: "BOM",
      cor: "#B8860B",
      emoji: "🟡",
      descricao: "Você tem boas bases e potencial para crescer ainda mais"
    };
  }
  if (pontos >= 21) {
    return {
      nivel: "REGULAR",
      cor: "#CD853F",
      emoji: "🟠",
      descricao: "Você está no caminho certo, mas pode desenvolver mais esta habilidade"
    };
  }
  return {
    nivel: "PRECISA ATENÇÃO",
    cor: "#A0522D",
    emoji: "🔴",
    descricao: "Esta área requer foco e desenvolvimento consciente"
  };
}

// Definir perfil baseado no padrão
export function definirPerfil(reflexao: number, juizo: number, decisao: number): Profile {
  const alto = (pontos: number) => pontos >= 31;
  const baixo = (pontos: number) => pontos < 21;
  const medio = (pontos: number) => pontos >= 21 && pontos < 31;

  const perfis: Profile[] = [
    {
      id: "sabio-equilibrado",
      nome: "SÁBIO EQUILIBRADO",
      descricao: "Você tem maturidade para refletir, julgar e agir com equilíbrio",
      frase: "Sua sabedoria reside na harmonia entre pensar e agir",
      cor: "#8B8B47",
      emoji: "🧘‍♂️",
      pontosFortes: [
        "Equilíbrio entre análise e ação",
        "Capacidade de decisões bem fundamentadas",
        "Autoconhecimento e consciência dos próprios limites",
        "Adaptabilidade a diferentes situações"
      ],
      oportunidades: [
        "Compartilhar sua sabedoria com outros",
        "Desenvolver ainda mais a intuição",
        "Explorar novas áreas de conhecimento",
        "Mentorear pessoas em desenvolvimento"
      ]
    },
    {
      id: "pensador-cuidadoso",
      nome: "PENSADOR CUIDADOSO",
      descricao: "Excelente análise, mas pode hesitar na execução",
      frase: "Sua força está na profundidade do pensamento",
      cor: "#8B7355",
      emoji: "🤔",
      pontosFortes: [
        "Análise profunda e detalhada",
        "Capacidade de prever consequências",
        "Paciência na tomada de decisão",
        "Busca por conhecimento e entendimento"
      ],
      oportunidades: [
        "Desenvolver mais confiança para agir",
        "Praticar decisões mais rápidas em situações simples",
        "Aceitar que decisões perfeitas são raras",
        "Equilibrar análise com ação"
      ]
    },
    {
      id: "executor-determinado",
      nome: "EXECUTOR DETERMINADO",
      descricao: "Age com firmeza, mas pode ser impulsivo",
      frase: "Sua força de vontade é admirável, mas precisa de mais reflexão",
      cor: "#6B5B47",
      emoji: "⚡",
      pontosFortes: [
        "Decisão rápida e firme",
        "Capacidade de execução e persistência",
        "Liderança natural",
        "Resiliência frente a obstáculos"
      ],
      oportunidades: [
        "Desenvolver mais paciência na análise",
        "Praticar a escuta ativa",
        "Considerar mais perspectivas antes de agir",
        "Buscar feedback antes de decidir"
      ]
    },
    {
      id: "analista-criterioso",
      nome: "ANALISTA CRITERIOSO",
      descricao: "Bom discernimento, precisa de mais ação",
      frase: "Sua capacidade de julgamento é seu maior trunfo",
      cor: "#A0956B",
      emoji: "🔍",
      pontosFortes: [
        "Discernimento aguçado",
        "Capacidade de avaliar situações complexas",
        "Objetividade na análise",
        "Bom senso crítico"
      ],
      oportunidades: [
        "Transformar análise em ação concreta",
        "Desenvolver mais iniciativa",
        "Praticar a tomada de decisão sob pressão",
        "Equilibrar critério com intuição"
      ]
    },
    {
      id: "observador-reflexivo",
      nome: "OBSERVADOR REFLEXIVO",
      descricao: "Escuta bem, precisa de mais decisão",
      frase: "Sua capacidade de observação é um dom valioso",
      cor: "#8B7355",
      emoji: "👁️",
      pontosFortes: [
        "Escuta ativa e empática",
        "Capacidade de observação detalhada",
        "Sensibilidade a diferentes perspectivas",
        "Paciência e reflexão"
      ],
      oportunidades: [
        "Desenvolver mais assertividade",
        "Praticar tomar decisões mesmo com informações incompletas",
        "Expressar suas opiniões com mais confiança",
        "Equilibrar escuta com ação"
      ]
    },
    {
      id: "aprendiz-desenvolvimento",
      nome: "APRENDIZ EM DESENVOLVIMENTO",
      descricao: "Base sólida para crescimento consciente",
      frase: "Sua jornada de desenvolvimento está apenas começando",
      cor: "#CD853F",
      emoji: "🌱",
      pontosFortes: [
        "Consciência da necessidade de crescimento",
        "Abertura para aprender e melhorar",
        "Potencial significativo para desenvolvimento",
        "Humildade para reconhecer limites"
      ],
      oportunidades: [
        "Desenvolver hábitos de reflexão diária",
        "Buscar mentoria e aprendizado contínuo",
        "Praticar decisões pequenas para ganhar confiança",
        "Estudar princípios de tomada de decisão"
      ]
    }
  ];

  // Lógica para determinar o perfil
  if (alto(reflexao) && alto(juizo) && alto(decisao)) {
    return perfis[0]; // Sábio Equilibrado
  }
  if (alto(reflexao) && alto(juizo) && baixo(decisao)) {
    return perfis[1]; // Pensador Cuidadoso
  }
  if (baixo(reflexao) && baixo(juizo) && alto(decisao)) {
    return perfis[2]; // Executor Determinado
  }
  if (medio(reflexao) && alto(juizo) && medio(decisao)) {
    return perfis[3]; // Analista Criterioso
  }
  if (alto(reflexao) && baixo(juizo) && baixo(decisao)) {
    return perfis[4]; // Observador Reflexivo
  }
  return perfis[5]; // Aprendiz em Desenvolvimento
}

// Calcular pontuações
export function calcularPontuacoes(respostas: { [key: number]: number }): ScoreResult {
  const reflexao = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].reduce((sum, id) => sum + (respostas[id] || 0), 0);
  const juizo = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20].reduce((sum, id) => sum + (respostas[id] || 0), 0);
  const decisao = [21, 22, 23, 24, 25, 26, 27, 28, 29, 30].reduce((sum, id) => sum + (respostas[id] || 0), 0);
  const total = reflexao + juizo + decisao;

  return { reflexao, juizo, decisao, total };
}

// Análise detalhada por bloco
export function analisarBloco(pontuacao: number, tipo: "reflexao" | "juizo" | "decisao"): BlockAnalysis {
  const classificacao = classificarPontuacao(pontuacao);

  const descricoes = {
    reflexao: {
      descricao: "A reflexão é a capacidade de observar, ponderar e considerar diferentes aspectos antes de formar uma opinião ou tomar uma decisão.",
      pontosFortes: [
        "Capacidade de análise profunda",
        "Consideração de múltiplas perspectivas",
        "Paciência na tomada de decisão",
        "Busca por conhecimento e entendimento"
      ],
      oportunidades: [
        "Desenvolver mais agilidade na análise",
        "Praticar a reflexão em situações do dia a dia",
        "Equilibrar tempo de análise com ação",
        "Compartilhar insights com outros"
      ],
      exemplo: "Ao enfrentar um problema complexo no trabalho, você reserva tempo para analisar todas as variáveis antes de propor uma solução."
    },
    juizo: {
      descricao: "O juízo é a capacidade de avaliar com clareza, discernir o que é importante e formar opiniões fundamentadas e equilibradas.",
      pontosFortes: [
        "Discernimento aguçado",
        "Capacidade de avaliar criticamente",
        "Objetividade na análise",
        "Equilíbrio entre razão e intuição"
      ],
      oportunidades: [
        "Desenvolver mais confiança no próprio julgamento",
        "Praticar a tomada de decisão com informações limitadas",
        "Buscar feedback para validar percepções",
        "Equilibrar critério com compaixão"
      ],
      exemplo: "Ao receber diferentes opiniões sobre um assunto, você consegue identificar os argumentos mais sólidos e formar uma posição bem fundamentada."
    },
    decisao: {
      descricao: "A decisão é a capacidade de agir com firmeza, comprometer-se com escolhas e colocar decisões em prática de forma consistente.",
      pontosFortes: [
        "Firmeza e determinação",
        "Capacidade de execução",
        "Assunção de responsabilidade",
        "Resiliência frente a obstáculos"
      ],
      oportunidades: [
        "Desenvolver mais flexibilidade",
        "Praticar a adaptação a novas circunstâncias",
        "Melhorar a comunicação das decisões",
        "Equilibrar firmeza com abertura"
      ],
      exemplo: "Depois de analisar todas as opções, você toma uma decisão clara e se compromete em colocá-la em prática, mesmo que enfrente dificuldades."
    }
  };

  return {
    pontuacao,
    classificacao,
    descricao: descricoes[tipo].descricao,
    pontosFortes: descricoes[tipo].pontosFortes.slice(0, 2),
    oportunidades: descricoes[tipo].oportunidades.slice(0, 2),
    exemplo: descricoes[tipo].exemplo
  };
}

// Gerar resultado completo
export function gerarResultadoCompleto(respostas: { [key: number]: number }): CompleteResult {
  const pontuacoes = calcularPontuacoes(respostas);
  const perfil = definirPerfil(pontuacoes.reflexao, pontuacoes.juizo, pontuacoes.decisao);
  const nivelGeral = classificarPontuacao(pontuacoes.total / 3); // Média geral

  return {
    perfil,
    pontuacoes,
    analise: {
      reflexao: analisarBloco(pontuacoes.reflexao, "reflexao"),
      juizo: analisarBloco(pontuacoes.juizo, "juizo"),
      decisao: analisarBloco(pontuacoes.decisao, "decisao")
    },
    nivelGeral
  };
}
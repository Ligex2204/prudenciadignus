"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download, 
  Share2, 
  Mail, 
  MessageCircle, 
  CheckCircle,
  Copy,
  Facebook,
  Twitter,
  Linkedin,
  MessageSquare,
  X
} from "lucide-react";
import { gerarResultadoCompleto, CompleteResult } from "@/lib/scoring";
import { SimplePDFGenerator } from "@/components/simple-pdf-generator";

interface SimpleShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'download' | 'share';
}

export function SimpleShareModal({ isOpen, onClose, type }: SimpleShareModalProps) {
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includePlan, setIncludePlan] = useState(true);
  const [customMessage, setCustomMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [result, setResult] = useState<CompleteResult | null>(null);

  if (!isOpen) return null;

  // Carregar resultados quando o modal abrir
  const loadResults = () => {
    const savedAnswers = localStorage.getItem("prudencia-answers");
    if (savedAnswers) {
      const answers = JSON.parse(savedAnswers);
      const completeResult = gerarResultadoCompleto(answers);
      setResult(completeResult);
    }
  };

  // Carregar resultados quando o modal abrir
  if (!result) {
    loadResults();
  }

  const handleShare = async (platform: string) => {
    setIsProcessing(true);
    
    const shareText = customMessage || "Acabei de fazer o Teste de Prudência e descobri meu perfil de decisor! Venha conhecer o seu também.";
    const shareUrl = window.location.origin;
    
    let shareLink = "";
    
    switch(platform) {
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'linkedin':
        shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        shareLink = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
        break;
      case 'email':
        shareLink = `mailto:?subject=${encodeURIComponent('Meu resultado do Teste de Prudência')}&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(shareText + ' ' + shareUrl);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
        setIsProcessing(false);
        return;
    }
    
    if (shareLink) {
      window.open(shareLink, '_blank', 'width=600,height=400');
    }
    
    setIsProcessing(false);
    onClose();
  };

  const copyToClipboard = () => {
    const shareText = customMessage || "Acabei de fazer o Teste de Prudência e descobri meu perfil de decisor! Venha conhecer o seu também.";
    const shareUrl = window.location.origin;
    navigator.clipboard.writeText(shareText + ' ' + shareUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  if (type === 'download') {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="space-y-2">
                <CardTitle className="flex items-center space-x-2">
                  <Download className="w-5 h-5 text-primary" />
                  <span>Baixar Relatório</span>
                </CardTitle>
                <CardDescription>
                  Escolha o conteúdo que deseja incluir
                </CardDescription>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={onClose}
                className="h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {result ? (
              <>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="charts"
                      checked={includeCharts}
                      onCheckedChange={(checked) => setIncludeCharts(checked as boolean)}
                    />
                    <Label htmlFor="charts" className="text-sm">
                      Incluir análise visual
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="plan"
                      checked={includePlan}
                      onCheckedChange={(checked) => setIncludePlan(checked as boolean)}
                    />
                    <Label htmlFor="plan" className="text-sm">
                      Incluir plano de ação
                    </Label>
                  </div>
                </div>
                
                <SimplePDFGenerator 
                  result={result} 
                  includeCharts={includeCharts} 
                  includePlan={includePlan} 
                />
              </>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">Carregando resultados...</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <CardTitle className="flex items-center space-x-2">
                <Share2 className="w-5 h-5 text-primary" />
                <span>Compartilhar Resultado</span>
              </CardTitle>
              <CardDescription>
                Compartilhe seu perfil e inspire outros
              </CardDescription>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="message" className="text-sm font-medium">
              Mensagem personalizada (opcional)
            </Label>
            <Input
              id="message"
              placeholder="Escreva sua mensagem aqui..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
            />
          </div>
          
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Compartilhar nas redes sociais</h4>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => handleShare('facebook')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Facebook className="w-4 h-4" />
                <span>Facebook</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('twitter')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Twitter className="w-4 h-4" />
                <span>Twitter</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('linkedin')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Linkedin className="w-4 h-4" />
                <span>LinkedIn</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('whatsapp')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </Button>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Outras opções</h4>
            <div className="space-y-2">
              <Button
                variant="outline"
                onClick={() => handleShare('email')}
                disabled={isProcessing}
                className="w-full flex items-center space-x-2"
              >
                <Mail className="w-4 h-4" />
                <span>Enviar por email</span>
              </Button>
              <Button
                variant="outline"
                onClick={copyToClipboard}
                disabled={isProcessing}
                className="w-full flex items-center space-x-2"
              >
                {isCopied ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-green-600">Link copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copiar link</span>
                  </>
                )}
              </Button>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={onClose}
              disabled={isProcessing}
              className="flex-1"
            >
              Fechar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
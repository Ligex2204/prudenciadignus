"use client";

import { CompleteResult } from "@/lib/scoring";
import { 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis,
  Radar,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ResponsiveContainer,
  Legend
} from "recharts";
import { Brain, Scale, Target, Star } from "lucide-react";

interface PDFReportProps {
  result: CompleteResult;
  includeCharts: boolean;
  includePlan: boolean;
}

export function PDFReport({ result, includeCharts, includePlan }: PDFReportProps) {
  // Dados para os gráficos
  const radarData = [
    { subject: "Reflexão", A: result.pontuacoes.reflexao, fullMark: 50 },
    { subject: "Juízo", A: result.pontuacoes.juizo, fullMark: 50 },
    { subject: "Decisão", A: result.pontuacoes.decisao, fullMark: 50 }
  ];

  const barData = [
    { name: "Reflexão", pontuacao: result.pontuacoes.reflexao, cor: "#8B7355" },
    { name: "Juízo", pontuacao: result.pontuacoes.juizo, cor: "#A0956B" },
    { name: "Decisão", pontuacao: result.pontuacoes.decisao, cor: "#6B5B47" }
  ];

  const pieData = [
    { name: "Reflexão", value: result.pontuacoes.reflexao, cor: "#8B7355" },
    { name: "Juízo", value: result.pontuacoes.juizo, cor: "#A0956B" },
    { name: "Decisão", value: result.pontuacoes.decisao, cor: "#6B5B47" }
  ];

  const evolutionData = [
    { dia: "Dia 1", atual: result.pontuacoes.reflexao * 0.7, potencial: result.pontuacoes.reflexao },
    { dia: "Dia 5", atual: result.pontuacoes.reflexao * 0.8, potencial: result.pontuacoes.reflexao },
    { dia: "Dia 10", atual: result.pontuacoes.reflexao * 0.9, potencial: result.pontuacoes.reflexao },
    { dia: "Dia 15", atual: result.pontuacoes.reflexao, potencial: result.pontuacoes.reflexao }
  ];

  return (
    <div className="bg-white p-8 max-w-4xl mx-auto" id="pdf-report">
      {/* Cabeçalho */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center space-x-2 mb-4">
          <div className="w-10 h-10 bg-[#8B7355] rounded-full flex items-center justify-center">
            <Brain className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800">Teste de Prudência</h1>
        </div>
        <h2 className="text-2xl font-semibold text-gray-700 mb-2">Relatório Personalizado</h2>
        <p className="text-gray-600">
          Gerado em {new Date().toLocaleDateString('pt-BR')} às {new Date().toLocaleTimeString('pt-BR')}
        </p>
      </div>

      {/* Perfil Principal */}
      <div className="bg-gradient-to-r from-[#8B7355] to-[#A0956B] text-white p-6 rounded-lg mb-8">
        <div className="text-center">
          <h3 className="text-2xl font-bold mb-2">Seu Perfil: {result.perfil.nome}</h3>
          <div className="text-4xl mb-2">{result.perfil.emoji}</div>
          <p className="text-lg opacity-90">{result.perfil.descricao}</p>
        </div>
      </div>

      {/* Análise Detalhada */}
      <div className="mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Análise Detalhada</h3>
        
        {/* Reflexão */}
        <div className="bg-gray-50 p-4 rounded-lg mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Brain className="w-5 h-5 text-[#8B7355]" />
            <h4 className="font-semibold text-gray-800">Reflexão</h4>
          </div>
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-xl">{result.analise.reflexao.classificacao.emoji}</span>
            <span className="font-semibold" style={{ color: result.analise.reflexao.classificacao.cor }}>
              {result.analise.reflexao.pontuacao} pts
            </span>
          </div>
          <p className="text-sm text-gray-600 mb-2">{result.analise.reflexao.descricao}</p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <strong className="text-gray-700">Pontos Fortes:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.reflexao.pontosFortes.map((ponto, index) => (
                  <li key={index}>{ponto}</li>
                ))}
              </ul>
            </div>
            <div>
              <strong className="text-gray-700">Oportunidades:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.reflexao.oportunidades.map((oportunidade, index) => (
                  <li key={index}>{oportunidade}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Juízo */}
        <div className="bg-gray-50 p-4 rounded-lg mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Scale className="w-5 h-5 text-[#A0956B]" />
            <h4 className="font-semibold text-gray-800">Juízo</h4>
          </div>
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-xl">{result.analise.juizo.classificacao.emoji}</span>
            <span className="font-semibold" style={{ color: result.analise.juizo.classificacao.cor }}>
              {result.analise.juizo.pontuacao} pts
            </span>
          </div>
          <p className="text-sm text-gray-600 mb-2">{result.analise.juizo.descricao}</p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <strong className="text-gray-700">Pontos Fortes:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.juizo.pontosFortes.map((ponto, index) => (
                  <li key={index}>{ponto}</li>
                ))}
              </ul>
            </div>
            <div>
              <strong className="text-gray-700">Oportunidades:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.juizo.oportunidades.map((oportunidade, index) => (
                  <li key={index}>{oportunidade}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Decisão */}
        <div className="bg-gray-50 p-4 rounded-lg mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <Target className="w-5 h-5 text-[#6B5B47]" />
            <h4 className="font-semibold text-gray-800">Decisão</h4>
          </div>
          <div className="flex items-center space-x-2 mb-2">
            <span className="text-xl">{result.analise.decisao.classificacao.emoji}</span>
            <span className="font-semibold" style={{ color: result.analise.decisao.classificacao.cor }}>
              {result.analise.decisao.pontuacao} pts
            </span>
          </div>
          <p className="text-sm text-gray-600 mb-2">{result.analise.decisao.descricao}</p>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <strong className="text-gray-700">Pontos Fortes:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.decisao.pontosFortes.map((ponto, index) => (
                  <li key={index}>{ponto}</li>
                ))}
              </ul>
            </div>
            <div>
              <strong className="text-gray-700">Oportunidades:</strong>
              <ul className="list-disc list-inside text-gray-600">
                {result.analise.decisao.oportunidades.map((oportunidade, index) => (
                  <li key={index}>{oportunidade}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Gráficos */}
      {includeCharts && (
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Visualização dos Resultados</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Gráfico Radar */}
            <div className="bg-white border border-gray-200 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700 mb-2 text-center">Distribuição das Competências</h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis angle={0} domain={[0, 50]} />
                    <Radar
                      name="Pontuação"
                      dataKey="A"
                      stroke="#8B7355"
                      fill="#8B7355"
                      fillOpacity={0.3}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Gráfico de Barras */}
            <div className="bg-white border border-gray-200 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700 mb-2 text-center">Comparação de Pontuações</h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Bar dataKey="pontuacao" fill="#8B7355" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Gráfico de Pizza */}
            <div className="bg-white border border-gray-200 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700 mb-2 text-center">Proporção das Competências</h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.cor} />
                      ))}
                    </Pie>
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Gráfico de Evolução */}
            <div className="bg-white border border-gray-200 p-4 rounded-lg">
              <h4 className="font-semibold text-gray-700 mb-2 text-center">Potencial de Evolução</h4>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={evolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="dia" />
                    <YAxis />
                    <Line type="monotone" dataKey="atual" stroke="#8B7355" strokeWidth={2} />
                    <Line type="monotone" dataKey="potencial" stroke="#A0956B" strokeWidth={2} strokeDasharray="5 5" />
                    <Legend />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Plano de Ação */}
      {includePlan && (
        <div className="mb-8">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Plano de Ação de 15 Dias</h3>
          
          <div className="space-y-4">
            {result.planoAcao.map((dia, index) => (
              <div key={index} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <div className="w-8 h-8 bg-[#8B7355] text-white rounded-full flex items-center justify-center font-semibold">
                    {dia.dia}
                  </div>
                  <h4 className="font-semibold text-gray-800">{dia.titulo}</h4>
                </div>
                <p className="text-sm text-gray-600 mb-2">{dia.descricao}</p>
                <div className="bg-white p-3 rounded border-l-4 border-[#8B7355]">
                  <strong className="text-sm text-gray-700">Exercício:</strong>
                  <p className="text-sm text-gray-600">{dia.exercicio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Rodapé */}
      <div className="text-center text-sm text-gray-600 border-t pt-4">
        <p>Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados</p>
        <p className="mt-1">Relatório confidencial - Uso pessoal</p>
      </div>
    </div>
  );
}
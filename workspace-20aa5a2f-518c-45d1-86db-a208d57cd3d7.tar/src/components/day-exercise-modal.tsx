"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Clock, 
  CheckCircle, 
  Circle, 
  BookOpen,
  Heart,
  Activity,
  Lightbulb,
  Award,
  X
} from "lucide-react";
import { DailyExercise } from "@/lib/action-plan";

interface DayExerciseModalProps {
  isOpen: boolean;
  onClose: () => void;
  exercise: DailyExercise;
  isCompleted: boolean;
  onToggleCompletion: (day: number) => void;
}

export function DayExerciseModal({ 
  isOpen, 
  onClose, 
  exercise, 
  isCompleted, 
  onToggleCompletion 
}: DayExerciseModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 sm:p-6">
      <Card className="w-full max-w-md sm:max-w-lg max-h-[85vh] sm:max-h-[90vh] overflow-y-auto mx-auto">
        <CardHeader className="pb-4 sm:pb-6">
          <div className="flex items-center justify-between">
            <div className="space-y-1 sm:space-y-2 flex-1 pr-2">
              <CardTitle className="text-xl sm:text-2xl font-serif text-foreground flex items-center space-x-2 sm:space-x-3">
                <span className="bg-primary text-primary-foreground w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center font-bold text-sm sm:text-base">
                  {exercise.dia}
                </span>
                <span className="text-lg sm:text-xl">Dia {exercise.dia}</span>
              </CardTitle>
              <div className="flex items-center space-x-3 sm:space-x-4 text-xs sm:text-sm text-muted-foreground">
                <div className="flex items-center space-x-1">
                  <Clock className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span>{exercise.tempo}</span>
                </div>
                <Badge variant={isCompleted ? "default" : "secondary"} className="text-xs">
                  {isCompleted ? "Concluído" : "Pendente"}
                </Badge>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              className="h-7 w-7 sm:h-8 sm:w-8 p-0 flex-shrink-0"
            >
              <X className="w-3 h-3 sm:w-4 sm:h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4 sm:space-y-6">
          {/* Formato Compacto */}
          <div className="space-y-3 sm:space-y-4">
            <h3 className="text-base sm:text-lg font-semibold text-foreground text-center mb-2 sm:mb-4">
              Sua Prática Diária
            </h3>
            
            {/* Silêncio */}
            <div className="bg-secondary/20 p-3 sm:p-4 rounded-xl border-l-4 border-primary">
              <div className="flex items-start space-x-2 sm:space-x-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-1">
                  <BookOpen className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground text-xs sm:text-sm mb-1">
                    🕯️ SILÊNCIO (2 min)
                  </h4>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {exercise.silencio}
                  </p>
                </div>
              </div>
            </div>

            {/* Escuta */}
            <div className="bg-secondary/20 p-3 sm:p-4 rounded-xl border-l-4 border-primary">
              <div className="flex items-start space-x-2 sm:space-x-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-1">
                  <Heart className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground text-xs sm:text-sm mb-1">
                    👂 ESCUTA (3 min)
                  </h4>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {exercise.escuta}
                  </p>
                </div>
              </div>
            </div>

            {/* Prática */}
            <div className="bg-secondary/20 p-3 sm:p-4 rounded-xl border-l-4 border-primary">
              <div className="flex items-start space-x-2 sm:space-x-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-1">
                  <Activity className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground text-xs sm:text-sm mb-1">
                    🧠 PRÁTICA (5 min)
                  </h4>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {exercise.pratica}
                  </p>
                </div>
              </div>
            </div>

            {/* Reflexão */}
            <div className="bg-secondary/20 p-3 sm:p-4 rounded-xl border-l-4 border-primary">
              <div className="flex items-start space-x-2 sm:space-x-3">
                <div className="w-6 h-6 sm:w-8 sm:h-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 sm:mt-1">
                  <Lightbulb className="w-3 h-3 sm:w-4 sm:h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-foreground text-xs sm:text-sm mb-1">
                    ✍️ REFLEXÃO (3 min)
                  </h4>
                  <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                    {exercise.reflexao}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Dica do Dia */}
          <div className="bg-primary/5 p-3 sm:p-4 rounded-xl border border-primary/20">
            <h4 className="font-semibold text-foreground mb-1 sm:mb-2 flex items-center space-x-1 sm:space-x-2">
              <Award className="w-4 h-4 sm:w-5 sm:h-5 text-primary" />
              <span className="text-sm sm:text-base">Dica do Dia</span>
            </h4>
            <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
              Lembre-se que a consistência é mais importante que a perfeição. 
              Mesmo que você não possa dedicar o tempo completo, faça o que puder. 
              Cada pequeno passo conta em sua jornada de desenvolvimento da prudência.
            </p>
          </div>

          {/* Checkbox de Conclusão */}
          <div className="flex items-center justify-center space-x-2 pt-3 sm:pt-4 border-t">
            <Checkbox
              id={`day-modal-${exercise.dia}`}
              checked={isCompleted}
              onCheckedChange={() => onToggleCompletion(exercise.dia)}
              className="w-4 h-4 sm:w-5 sm:h-5"
            />
            <label
              htmlFor={`day-modal-${exercise.dia}`}
              className="text-xs sm:text-sm font-medium cursor-pointer"
            >
              Marcar como concluído
            </label>
          </div>

          {/* Botão Fechar */}
          <Button 
            onClick={onClose}
            className="w-full text-sm sm:text-base py-2 sm:py-3"
          >
            Fechar
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
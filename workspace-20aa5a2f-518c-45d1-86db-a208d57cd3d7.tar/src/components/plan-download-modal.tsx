"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download, 
  X,
  Calendar,
  Target,
  CheckCircle
} from "lucide-react";
import { CompleteResult } from "@/lib/scoring";
import { determinarFoco, actionPlans } from "@/lib/action-plan";

interface PlanDownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: CompleteResult;
}

export function PlanDownloadModal({ isOpen, onClose, result }: PlanDownloadModalProps) {
  const [includeExercises, setIncludeExercises] = useState(true);
  const [includeProgress, setIncludeProgress] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!isOpen) return null;

  const foco = determinarFoco(result.pontuacoes);
  const currentPlan = actionPlans[foco];

  const generatePlanHTMLContent = () => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Plano de Ação - Teste de Prudência</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
          }
          .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #8B7355;
            padding-bottom: 20px;
          }
          .title {
            font-size: 28px;
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 10px;
          }
          .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 10px;
          }
          .date {
            font-size: 14px;
            color: #888;
          }
          .profile {
            background: linear-gradient(135deg, #8B7355, #A0956B);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
          }
          .profile-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .profile-emoji {
            font-size: 36px;
            margin-bottom: 10px;
          }
          .profile-desc {
            font-size: 16px;
            opacity: 0.9;
          }
          .plan-intro {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            border-left: 4px solid #8B7355;
          }
          .plan-title {
            font-size: 22px;
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 10px;
          }
          .plan-desc {
            font-size: 16px;
            color: #666;
            margin-bottom: 15px;
          }
          .plan-focus {
            background: #8B7355;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            display: inline-block;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .plan-day {
            background: #f9f9f9;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 10px;
            border-left: 4px solid #8B7355;
          }
          .plan-day-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 15px;
          }
          .plan-day-title {
            font-size: 18px;
            font-weight: bold;
            color: #8B7355;
          }
          .plan-day-number {
            background: #8B7355;
            color: white;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 14px;
          }
          .plan-day-desc {
            font-size: 15px;
            color: #666;
            margin-bottom: 15px;
          }
          .plan-exercise {
            background: white;
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid #8B7355;
            margin-bottom: 10px;
          }
          .exercise-title {
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 8px;
          }
          .exercise-desc {
            font-size: 14px;
            color: #666;
          }
          .progress-section {
            background: #f0f0f0;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
          }
          .progress-title {
            font-size: 18px;
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 15px;
          }
          .progress-bar {
            background: #ddd;
            height: 20px;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 10px;
          }
          .progress-fill {
            background: #8B7355;
            height: 100%;
            width: 0%;
            transition: width 0.3s ease;
          }
          .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #888;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="title">Plano de Ação de 15 Dias</div>
            <div class="subtitle">Teste de Prudência - Plano Personalizado</div>
            <div class="date">Gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</div>
          </div>

          <div class="profile">
            <div class="profile-title">Seu Perfil: ${result.perfil.nome}</div>
            <div class="profile-emoji">${result.perfil.emoji}</div>
            <div class="profile-desc">${result.perfil.descricao}</div>
          </div>

          <div class="plan-intro">
            <div class="plan-title">${currentPlan.titulo}</div>
            <div class="plan-desc">${currentPlan.descricao}</div>
            <div class="plan-focus">Foco: ${foco.charAt(0).toUpperCase() + foco.slice(1)}</div>
          </div>

          ${includeProgress ? `
          <div class="progress-section">
            <div class="progress-title">Seu Progresso</div>
            <div class="progress-bar">
              <div class="progress-fill"></div>
            </div>
            <p>Marque cada dia conforme completar os exercícios</p>
          </div>
          ` : ''}

          <div class="plan-section">
            ${currentPlan.exercicios.map((exercicio) => `
              <div class="plan-day">
                <div class="plan-day-header">
                  <div class="plan-day-title">Dia ${exercicio.dia}</div>
                  <div class="plan-day-number">${exercicio.dia}</div>
                </div>
                <div class="plan-day-desc">
                  <strong>Tempo necessário:</strong> ${exercicio.tempo}
                </div>
                
                ${includeExercises ? `
                  <div class="plan-exercise">
                    <div class="exercise-title">🧘 Silêncio</div>
                    <div class="exercise-desc">${exercicio.silencio}</div>
                  </div>
                  
                  <div class="plan-exercise">
                    <div class="exercise-title">👂 Escuta</div>
                    <div class="exercise-desc">${exercicio.escuta}</div>
                  </div>
                  
                  <div class="plan-exercise">
                    <div class="exercise-title">💪 Prática</div>
                    <div class="exercise-desc">${exercicio.pratica}</div>
                  </div>
                  
                  <div class="plan-exercise">
                    <div class="exercise-title">🤔 Reflexão</div>
                    <div class="exercise-desc">${exercicio.reflexao}</div>
                  </div>
                ` : `
                  <div class="plan-exercise">
                    <div class="exercise-title">Exercício do Dia</div>
                    <div class="exercise-desc">
                      Complete os quatro módulos: Silêncio, Escuta, Prática e Reflexão (${exercicio.tempo})
                    </div>
                  </div>
                `}
              </div>
            `).join('')}
          </div>

          <div class="footer">
            <p>Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados</p>
            <p>Plano de ação personalizado - Uso pessoal</p>
          </div>
        </div>
      </body>
      </html>
    `;
  };

  const downloadPlan = async () => {
    setIsProcessing(true);
    try {
      // Verificar se temos os dados necessários
      if (!result || !currentPlan || !currentPlan.exercicios) {
        throw new Error('Dados do plano não disponíveis');
      }

      const htmlContent = generatePlanHTMLContent();
      
      // Verificar se o conteúdo foi gerado corretamente
      if (!htmlContent || htmlContent.length < 100) {
        throw new Error('Erro ao gerar conteúdo do plano');
      }
      
      // Criar um blob com o conteúdo HTML
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      
      // Tentar abrir uma nova janela para imprimir
      const printWindow = window.open(url, '_blank');
      
      if (printWindow) {
        printWindow.onload = () => {
          setTimeout(() => {
            try {
              printWindow.print();
              // Fechar a janela após alguns segundos
              setTimeout(() => {
                printWindow.close();
                URL.revokeObjectURL(url);
                setIsProcessing(false);
              }, 1000);
            } catch (printError) {
              console.error('Erro ao imprimir:', printError);
              // Fallback para download
              fallbackDownload(url);
            }
          }, 500);
        };
        
        // Fallback se a janela não carregar
        setTimeout(() => {
          if (printWindow.closed) {
            URL.revokeObjectURL(url);
            setIsProcessing(false);
          }
        }, 5000);
      } else {
        // Fallback: download como HTML
        fallbackDownload(url);
      }
    } catch (error) {
      console.error('Erro ao gerar plano:', error);
      alert('Ocorreu um erro ao gerar o plano. Por favor, tente novamente ou contate o suporte.');
      setIsProcessing(false);
    }
  };

  const fallbackDownload = (url: string) => {
    try {
      const link = document.createElement('a');
      link.href = url;
      link.download = `plano-acao-prudencia-${new Date().toISOString().split('T')[0]}.html`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      setTimeout(() => {
        URL.revokeObjectURL(url);
        setIsProcessing(false);
      }, 1000);
    } catch (error) {
      console.error('Erro no fallback download:', error);
      alert('Não foi possível baixar o plano. Por favor, tente novamente mais tarde.');
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <CardTitle className="flex items-center space-x-2">
                <Download className="w-5 h-5 text-primary" />
                <span>Baixar Plano de Ação</span>
              </CardTitle>
              <CardDescription>
                Seu plano personalizado de 15 dias
              </CardDescription>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="exercises"
                checked={includeExercises}
                onCheckedChange={(checked) => setIncludeExercises(checked as boolean)}
              />
              <Label htmlFor="exercises" className="text-sm">
                Incluir exercícios detalhados
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="progress"
                checked={includeProgress}
                onCheckedChange={(checked) => setIncludeProgress(checked as boolean)}
              />
              <Label htmlFor="progress" className="text-sm">
                Incluir seção de progresso
              </Label>
            </div>
          </div>
          
          <div className="text-center">
            <button
              onClick={downloadPlan}
              disabled={isProcessing}
              className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium w-full disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin inline-block mr-2"></div>
                  Gerando plano...
                </>
              ) : (
                'Baixar Plano de Ação'
              )}
            </button>
            <p className="text-sm text-muted-foreground mt-2">
              Clique para gerar e baixar seu plano personalizado
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download, 
  Share2, 
  Mail, 
  MessageCircle, 
  FileText,
  CheckCircle,
  Copy,
  Facebook,
  Twitter,
  Linkedin,
  MessageSquare
} from "lucide-react";
import { gerarResultadoCompleto, CompleteResult } from "@/lib/scoring";
import { PDFReport } from "@/components/pdf-report";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'download' | 'share';
}

export function ShareModal({ isOpen, onClose, type }: ShareModalProps) {
  const [email, setEmail] = useState("");
  const [includeCharts, setIncludeCharts] = useState(true);
  const [includePlan, setIncludePlan] = useState(true);
  const [customMessage, setCustomMessage] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCopied, setIsCopied] = useState(false);

  if (!isOpen) return null;

  const handleDownload = async () => {
    setIsProcessing(true);
    
    try {
      // Obter os resultados do localStorage
      const savedAnswers = localStorage.getItem("prudencia-answers");
      if (!savedAnswers) {
        alert("Nenhum resultado encontrado para gerar o PDF.");
        setIsProcessing(false);
        return;
      }
      
      const answers = JSON.parse(savedAnswers);
      const result: CompleteResult = gerarResultadoCompleto(answers);
      
      // Criar um elemento temporário para o relatório
      const tempDiv = document.createElement('div');
      tempDiv.style.position = 'absolute';
      tempDiv.style.left = '-9999px';
      tempDiv.style.top = '-9999px';
      tempDiv.style.width = '800px';
      document.body.appendChild(tempDiv);
      
      // Renderizar o componente PDFReport no elemento temporário
      const pdfReportElement = document.createElement('div');
      tempDiv.appendChild(pdfReportElement);
      
      // Criar uma instância do React para renderizar o componente
      const ReactDOM = await import('react-dom/client');
      const root = ReactDOM.createRoot(pdfReportElement);
      root.render(<PDFReport result={result} includeCharts={includeCharts} includePlan={includePlan} />);
      
      // Esperar um pouco para o componente renderizar
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Capturar o elemento como imagem
      const canvas = await html2canvas(pdfReportElement, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });
      
      // Criar o PDF
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      
      let position = 0;
      
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
      
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      // Salvar o PDF
      const fileName = `teste-prudencia-${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(fileName);
      
      // Limpar o elemento temporário
      document.body.removeChild(tempDiv);
      
      // Se foi fornecido um email, abrir o cliente de email com o PDF anexo
      if (email) {
        const subject = encodeURIComponent('Meu resultado do Teste de Prudência');
        const body = encodeURIComponent(`Olá!\n\nAcabei de fazer o Teste de Prudência e estou compartilhando meu resultado em anexo.\n\nAtenciosamente,`);
        window.location.href = `mailto:${email}?subject=${subject}&body=${body}`;
      }
      
      setIsProcessing(false);
      onClose();
      
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert('Ocorreu um erro ao gerar o PDF. Por favor, tente novamente.');
      setIsProcessing(false);
    }
  };

  const handleShare = async (platform: string) => {
    setIsProcessing(true);
    
    // Simulação de compartilhamento
    const shareText = customMessage || "Acabei de fazer o Teste de Prudência e descobri meu perfil de decisor! Venha conhecer o seu também.";
    const shareUrl = window.location.origin;
    
    let shareLink = "";
    
    switch(platform) {
      case 'facebook':
        shareLink = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}&quote=${encodeURIComponent(shareText)}`;
        break;
      case 'twitter':
        shareLink = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'linkedin':
        shareLink = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'whatsapp':
        shareLink = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
        break;
      case 'email':
        shareLink = `mailto:?subject=${encodeURIComponent('Meu resultado do Teste de Prudência')}&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`;
        break;
      case 'copy':
        navigator.clipboard.writeText(shareText + ' ' + shareUrl);
        setIsCopied(true);
        setTimeout(() => setIsCopied(false), 2000);
        setIsProcessing(false);
        return;
    }
    
    if (shareLink) {
      window.open(shareLink, '_blank', 'width=600,height=400');
    }
    
    setIsProcessing(false);
    onClose();
  };

  const copyToClipboard = () => {
    const shareText = customMessage || "Acabei de fazer o Teste de Prudência e descobri meu perfil de decisor! Venha conhecer o seu também.";
    const shareUrl = window.location.origin;
    navigator.clipboard.writeText(shareText + ' ' + shareUrl);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  if (type === 'download') {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Download className="w-5 h-5 text-primary" />
              <span>Baixar Relatório Completo</span>
            </CardTitle>
            <CardDescription>
              Escolha o conteúdo que deseja incluir no seu PDF
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="charts"
                  checked={includeCharts}
                  onCheckedChange={(checked) => setIncludeCharts(checked as boolean)}
                />
                <Label htmlFor="charts" className="text-sm">
                  Incluir gráficos e análises
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="plan"
                  checked={includePlan}
                  onCheckedChange={(checked) => setIncludePlan(checked as boolean)}
                />
                <Label htmlFor="plan" className="text-sm">
                  Incluir plano de ação de 15 dias
                </Label>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">
                Email para envio (opcional)
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="seu@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            
            <div className="flex space-x-2">
              <Button 
                onClick={handleDownload}
                disabled={isProcessing}
                className="flex-1"
              >
                {isProcessing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Gerando...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Baixar PDF
                  </>
                )}
              </Button>
              <Button 
                variant="outline" 
                onClick={onClose}
                disabled={isProcessing}
              >
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Share2 className="w-5 h-5 text-primary" />
            <span>Compartilhar Seu Resultado</span>
          </CardTitle>
          <CardDescription>
            Compartilhe seu perfil e inspire outros a desenvolverem sua prudência
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="message" className="text-sm font-medium">
              Mensagem personalizada (opcional)
            </Label>
            <Textarea
              id="message"
              placeholder="Escreva sua mensagem aqui..."
              value={customMessage}
              onChange={(e) => setCustomMessage(e.target.value)}
              rows={3}
            />
          </div>
          
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Compartilhar nas redes sociais</h4>
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => handleShare('facebook')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Facebook className="w-4 h-4" />
                <span>Facebook</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('twitter')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Twitter className="w-4 h-4" />
                <span>Twitter</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('linkedin')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <Linkedin className="w-4 h-4" />
                <span>LinkedIn</span>
              </Button>
              <Button
                variant="outline"
                onClick={() => handleShare('whatsapp')}
                disabled={isProcessing}
                className="flex items-center space-x-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp</span>
              </Button>
            </div>
          </div>
          
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Outras opções</h4>
            <div className="space-y-2">
              <Button
                variant="outline"
                onClick={() => handleShare('email')}
                disabled={isProcessing}
                className="w-full flex items-center space-x-2"
              >
                <Mail className="w-4 h-4" />
                <span>Enviar por email</span>
              </Button>
              <Button
                variant="outline"
                onClick={copyToClipboard}
                disabled={isProcessing}
                className="w-full flex items-center space-x-2"
              >
                {isCopied ? (
                  <>
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span className="text-green-600">Link copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copiar link</span>
                  </>
                )}
              </Button>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              onClick={onClose}
              disabled={isProcessing}
              className="flex-1"
            >
              Fechar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
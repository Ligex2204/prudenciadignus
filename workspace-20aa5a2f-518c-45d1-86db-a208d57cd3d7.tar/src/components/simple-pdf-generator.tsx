"use client";

import { CompleteResult } from "@/lib/scoring";
import { Brain, Scale, Target, Star } from "lucide-react";

interface SimplePDFGeneratorProps {
  result: CompleteResult;
  includeCharts: boolean;
  includePlan: boolean;
}

export function SimplePDFGenerator({ result, includeCharts, includePlan }: SimplePDFGeneratorProps) {
  const mediaGeral = Math.round((result.pontuacoes.total / 3) * 10) / 10;

  const generateHTMLContent = () => {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Teste de Prudência - Relatório</title>
        <style>
          * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
          }
          body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
          }
          .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #8B7355;
            padding-bottom: 20px;
          }
          .title {
            font-size: 28px;
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 10px;
          }
          .subtitle {
            font-size: 18px;
            color: #666;
            margin-bottom: 10px;
          }
          .date {
            font-size: 14px;
            color: #888;
          }
          .profile {
            background: linear-gradient(135deg, #8B7355, #A0956B);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: center;
          }
          .profile-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .profile-emoji {
            font-size: 36px;
            margin-bottom: 10px;
          }
          .profile-desc {
            font-size: 16px;
            opacity: 0.9;
          }
          .section {
            margin-bottom: 30px;
          }
          .section-title {
            font-size: 20px;
            font-weight: bold;
            color: #8B7355;
            margin-bottom: 15px;
            border-left: 4px solid #8B7355;
            padding-left: 10px;
          }
          .competence {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid #ddd;
          }
          .competence-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
          }
          .competence-score {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 8px;
          }
          .competence-desc {
            font-size: 14px;
            margin-bottom: 10px;
          }
          .points {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            font-size: 13px;
          }
          .points h4 {
            font-weight: bold;
            margin-bottom: 5px;
            color: #555;
          }
          .points ul {
            list-style-type: disc;
            padding-left: 20px;
          }
          .points li {
            margin-bottom: 3px;
          }
          .stats {
            background: #f0f0f0;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
          }
          .stats-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 10px;
          }
          .stats-value {
            font-size: 24px;
            font-weight: bold;
            color: #8B7355;
          }
          .stats-desc {
            font-size: 14px;
            color: #666;
          }
          .plan-day {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            border-left: 4px solid #8B7355;
          }
          .plan-day-title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
          }
          .plan-day-desc {
            font-size: 14px;
            margin-bottom: 10px;
          }
          .plan-exercise {
            background: white;
            padding: 10px;
            border-radius: 5px;
            border-left: 3px solid #8B7355;
            font-size: 13px;
          }
          .footer {
            text-align: center;
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            font-size: 12px;
            color: #888;
          }
          .chart-placeholder {
            background: #f0f0f0;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            margin-bottom: 15px;
            color: #666;
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <div class="title">Teste de Prudência</div>
            <div class="subtitle">Relatório Personalizado</div>
            <div class="date">Gerado em ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}</div>
          </div>

          <div class="profile">
            <div class="profile-title">Seu Perfil: ${result.perfil.nome}</div>
            <div class="profile-emoji">${result.perfil.emoji}</div>
            <div class="profile-desc">${result.perfil.descricao}</div>
          </div>

          <div class="stats">
            <div class="stats-title">Média Geral</div>
            <div class="stats-value">${mediaGeral}</div>
            <div class="stats-desc">${result.nivelGeral.nivel} - ${result.nivelGeral.descricao}</div>
          </div>

          ${includeCharts ? `
          <div class="section">
            <div class="section-title">Visualização dos Resultados</div>
            <div class="chart-placeholder">
              Gráficos de visualização não disponíveis neste formato simplificado
            </div>
          </div>
          ` : ''}

          <div class="section">
            <div class="section-title">Análise Detalhada</div>
            
            <div class="competence">
              <div class="competence-title">
                🧠 Reflexão
              </div>
              <div class="competence-score" style="color: ${result.analise.reflexao.classificacao.cor}">
                ${result.analise.reflexao.pontuacao} pts - ${result.analise.reflexao.classificacao.nivel}
              </div>
              <div class="competence-desc">${result.analise.reflexao.descricao}</div>
              <div class="points">
                <div>
                  <h4>Pontos Fortes:</h4>
                  <ul>
                    ${result.analise.reflexao.pontosFortes.map(ponto => `<li>${ponto}</li>`).join('')}
                  </ul>
                </div>
                <div>
                  <h4>Oportunidades:</h4>
                  <ul>
                    ${result.analise.reflexao.oportunidades.map(oportunidade => `<li>${oportunidade}</li>`).join('')}
                  </ul>
                </div>
              </div>
            </div>

            <div class="competence">
              <div class="competence-title">
                ⚖️ Juízo
              </div>
              <div class="competence-score" style="color: ${result.analise.juizo.classificacao.cor}">
                ${result.analise.juizo.pontuacao} pts - ${result.analise.juizo.classificacao.nivel}
              </div>
              <div class="competence-desc">${result.analise.juizo.descricao}</div>
              <div class="points">
                <div>
                  <h4>Pontos Fortes:</h4>
                  <ul>
                    ${result.analise.juizo.pontosFortes.map(ponto => `<li>${ponto}</li>`).join('')}
                  </ul>
                </div>
                <div>
                  <h4>Oportunidades:</h4>
                  <ul>
                    ${result.analise.juizo.oportunidades.map(oportunidade => `<li>${oportunidade}</li>`).join('')}
                  </ul>
                </div>
              </div>
            </div>

            <div class="competence">
              <div class="competence-title">
                🎯 Decisão
              </div>
              <div class="competence-score" style="color: ${result.analise.decisao.classificacao.cor}">
                ${result.analise.decisao.pontuacao} pts - ${result.analise.decisao.classificacao.nivel}
              </div>
              <div class="competence-desc">${result.analise.decisao.descricao}</div>
              <div class="points">
                <div>
                  <h4>Pontos Fortes:</h4>
                  <ul>
                    ${result.analise.decisao.pontosFortes.map(ponto => `<li>${ponto}</li>`).join('')}
                  </ul>
                </div>
                <div>
                  <h4>Oportunidades:</h4>
                  <ul>
                    ${result.analise.decisao.oportunidades.map(oportunidade => `<li>${oportunidade}</li>`).join('')}
                  </ul>
                </div>
              </div>
            </div>
          </div>

          ${includePlan && result.planoAcao ? `
          <div class="section">
            <div class="section-title">Plano de Ação de 15 Dias</div>
            ${result.planoAcao.map((dia, index) => `
              <div class="plan-day">
                <div class="plan-day-title">
                  <span style="background: #8B7355; color: white; width: 24px; height: 24px; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; font-weight: bold; font-size: 12px;">
                    ${dia.dia}
                  </span>
                  ${dia.titulo}
                </div>
                <div class="plan-day-desc">${dia.descricao}</div>
                <div class="plan-exercise">
                  <strong>Exercício:</strong> ${dia.exercicio}
                </div>
              </div>
            `).join('')}
          </div>
          ` : ''}

          <div class="footer">
            <p>Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados</p>
            <p>Relatório confidencial - Uso pessoal</p>
          </div>
        </div>
      </body>
      </html>
    `;
  };

  const downloadPDF = async () => {
    try {
      const htmlContent = generateHTMLContent();
      
      // Criar um blob com o conteúdo HTML
      const blob = new Blob([htmlContent], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      
      // Criar uma nova janela para imprimir
      const printWindow = window.open(url, '_blank');
      
      if (printWindow) {
        printWindow.onload = () => {
          setTimeout(() => {
            printWindow.print();
            // Fechar a janela após alguns segundos
            setTimeout(() => {
              printWindow.close();
              URL.revokeObjectURL(url);
            }, 1000);
          }, 500);
        };
      } else {
        // Fallback: download como HTML
        const link = document.createElement('a');
        link.href = url;
        link.download = `teste-prudencia-${new Date().toISOString().split('T')[0]}.html`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error('Erro ao gerar PDF:', error);
      alert('Ocorreu um erro ao gerar o PDF. Por favor, tente novamente.');
    }
  };

  return (
    <div className="text-center">
      <button
        onClick={downloadPDF}
        className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg font-medium"
      >
        Baixar Relatório (PDF/HTML)
      </button>
      <p className="text-sm text-muted-foreground mt-2">
        Clique para gerar e baixar seu relatório personalizado
      </p>
    </div>
  );
}
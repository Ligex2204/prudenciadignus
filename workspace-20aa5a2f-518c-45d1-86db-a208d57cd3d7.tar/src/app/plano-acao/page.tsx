"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { 
  Calendar, 
  Clock, 
  CheckCircle, 
  Circle, 
  Target, 
  Award,
  Download,
  Share2,
  RotateCcw,
  BookOpen,
  Lightbulb,
  Heart,
  Activity,
  ArrowLeft
} from "lucide-react";
import { gerarResultadoCompleto } from "@/lib/scoring";
import { actionPlans, determinarFoco, DailyExercise } from "@/lib/action-plan";
import { SimpleShareModal } from "@/components/simple-share-modal";
import { DayExerciseModal } from "@/components/day-exercise-modal";
import { PlanDownloadModal } from "@/components/plan-download-modal";
import Link from "next/link";

interface CompletedDays {
  [key: number]: boolean;
}

export default function PlanoAcaoPage() {
  const [result, setResult] = useState<any>(null);
  const [completedDays, setCompletedDays] = useState<CompletedDays>({});
  const [currentDay, setCurrentDay] = useState(1);
  const [isLoading, setIsLoading] = useState(true);
  const [showShareModal, setShowShareModal] = useState(false);
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [showExerciseModal, setShowExerciseModal] = useState(false);

  useEffect(() => {
    // Carregar resultados do localStorage
    const savedAnswers = localStorage.getItem("prudencia-answers");
    if (savedAnswers) {
      const answers = JSON.parse(savedAnswers);
      const completeResult = gerarResultadoCompleto(answers);
      setResult(completeResult);
      
      // Determinar foco e carregar plano
      const foco = determinarFoco(completeResult.pontuacoes);
      setCurrentPlan(actionPlans[foco]);
    }
    
    // Carregar dias completos do localStorage
    const savedCompleted = localStorage.getItem("prudencia-completed-days");
    if (savedCompleted) {
      setCompletedDays(JSON.parse(savedCompleted));
    }
    
    setIsLoading(false);
  }, []);

  const [currentPlan, setCurrentPlan] = useState(actionPlans.reflexao);

  useEffect(() => {
    // Salvar dias completos no localStorage
    localStorage.setItem("prudencia-completed-days", JSON.stringify(completedDays));
  }, [completedDays]);

  const toggleDayCompletion = (day: number) => {
    setCompletedDays(prev => ({
      ...prev,
      [day]: !prev[day]
    }));
  };

  const handleDownload = () => {
    setShowPlanModal(true);
  };

  const handleShare = () => {
    setShowShareModal(true);
  };

  const openExerciseModal = (day: number) => {
    setCurrentDay(day);
    setShowExerciseModal(true);
  };

  const completedCount = Object.values(completedDays).filter(Boolean).length;
  const progress = (completedCount / 15) * 100;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-muted-foreground">Preparando seu plano personalizado...</p>
        </div>
      </div>
    );
  }

  if (!result || !currentPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Nenhum plano encontrado.</p>
            <Button asChild>
              <Link href="/questionario">Fazer Teste</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Target className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-serif font-semibold text-foreground">
                Teste de Prudência
              </h1>
            </Link>
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Button variant="outline" size="sm" asChild className="text-xs sm:text-sm">
                <Link href="/resultados">
                  <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                  <span className="hidden sm:inline">Voltar</span>
                </Link>
              </Button>
              <Button variant="outline" size="sm" onClick={handleDownload} className="text-xs sm:text-sm">
                <Download className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Baixar Plano</span>
                <span className="sm:hidden">PDF</span>
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare} className="text-xs sm:text-sm">
                <Share2 className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                <span className="hidden sm:inline">Compartilhar</span>
                <span className="sm:hidden">Share</span>
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-6xl px-4 py-4 sm:py-8 space-y-6 sm:space-y-8">
        {/* Cabeçalho do Plano */}
        <section className="text-center space-y-4 sm:space-y-6">
          <div className="space-y-3 sm:space-y-4">
            <Badge variant="secondary" className="text-base sm:text-lg px-3 sm:px-4 py-2 rounded-full">
              {currentPlan.titulo}
            </Badge>
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-serif font-bold text-foreground leading-tight">
              Seu Plano de Ação de 15 Dias
            </h1>
            <p className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed px-4">
              {currentPlan.descricao}
            </p>
          </div>

          {/* Progresso Geral */}
          <div className="max-w-md mx-auto px-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">Progresso</span>
              <span className="text-sm font-medium text-foreground">
                {completedCount} de 15 dias
              </span>
            </div>
            <Progress value={progress} className="h-2 sm:h-3" />
            <p className="text-xs text-muted-foreground mt-2">
              {Math.round(progress)}% completado
            </p>
          </div>
        </section>

        {/* Calendário Visual */}
        <section className="px-2 sm:px-0">
          <Card className="bg-card border-border/50 shadow-lg">
            <CardHeader className="pb-4 sm:pb-6">
              <CardTitle className="text-xl sm:text-2xl font-serif text-foreground flex items-center space-x-2">
                <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                <span>Seu Calendário de Desenvolvimento</span>
              </CardTitle>
              <CardDescription className="text-sm sm:text-base">
                Clique em cada dia para ver os exercícios em formato compacto e marcar como concluído
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 sm:gap-4">
                {currentPlan.exercicios.map((exercicio) => (
                  <button
                    key={exercicio.dia}
                    onClick={() => openExerciseModal(exercicio.dia)}
                    className={`p-3 sm:p-4 rounded-xl border-2 transition-all duration-300 hover:scale-105 active:scale-95 ${
                      completedDays[exercicio.dia]
                        ? "bg-primary/10 border-primary text-primary"
                        : "bg-card border-border hover:border-primary/50 text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <div className="text-center space-y-1 sm:space-y-2">
                      <div className="text-xl sm:text-2xl">
                        {completedDays[exercicio.dia] ? (
                          <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 mx-auto" />
                        ) : (
                          <Circle className="w-5 h-5 sm:w-6 sm:h-6 mx-auto" />
                        )}
                      </div>
                      <div className="font-semibold text-sm sm:text-base">Dia {exercicio.dia}</div>
                      <div className="text-xs opacity-75">{exercicio.tempo}</div>
                    </div>
                  </button>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Seção Final - Conclusão */}
        {completedCount === 15 && (
          <section className="text-center">
            <Card className="bg-gradient-to-r from-primary to-secondary text-white">
              <CardContent className="pt-8 pb-8">
                <div className="space-y-4">
                  <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto">
                    <Award className="w-10 h-10 text-white" />
                  </div>
                  <h2 className="text-3xl font-serif font-bold">
                    Parabéns! Jornada Concluída
                  </h2>
                  <p className="text-lg opacity-90 max-w-2xl mx-auto">
                    Você completou seu plano de 15 dias para desenvolver sua prudência. 
                    Este é apenas o começo de uma jornada contínua de crescimento e sabedoria.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button asChild variant="secondary" className="bg-white text-primary hover:bg-white/90">
                      <Link href="/resultados">
                        Ver Resultados
                        <Target className="ml-2 w-5 h-5" />
                      </Link>
                    </Button>
                    <Button asChild variant="outline" className="border-2 border-white text-white hover:bg-white hover:text-primary">
                      <Link href="/questionario">
                        <RotateCcw className="mr-2 w-5 h-5" />
                        Refazer Teste
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
        )}
      </div>
      
      {/* Day Exercise Modal */}
      {currentPlan.exercicios
        .filter(ex => ex.dia === currentDay)
        .map((exercicio) => (
          <DayExerciseModal
            key={exercicio.dia}
            isOpen={showExerciseModal}
            onClose={() => setShowExerciseModal(false)}
            exercise={exercicio}
            isCompleted={completedDays[exercicio.dia] || false}
            onToggleCompletion={toggleDayCompletion}
          />
        ))}
      
      {/* Share Modal */}
      <SimpleShareModal 
        isOpen={showShareModal} 
        onClose={() => setShowShareModal(false)} 
        type={'share'} 
      />
      
      {/* Plan Download Modal */}
      {result && (
        <PlanDownloadModal 
          isOpen={showPlanModal} 
          onClose={() => setShowPlanModal(false)} 
          result={result} 
        />
      )}
      
      {/* Footer */}
      <footer className="border-t border-border/50 bg-background py-6 px-4 mt-8">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <Target className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">
                Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
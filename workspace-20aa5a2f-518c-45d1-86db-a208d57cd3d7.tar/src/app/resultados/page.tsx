"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  ResponsiveContainer,
  Legend
} from "recharts";
import { 
  Brain, 
  Scale, 
  Target, 
  Download, 
  Share2, 
  RotateCcw,
  TrendingUp,
  Award,
  Star
} from "lucide-react";
import { gerarResultadoCompleto, CompleteResult } from "@/lib/scoring";
import { SimpleShareModal } from "@/components/simple-share-modal";
import Link from "next/link";

export default function ResultadosPage() {
  const [result, setResult] = useState<CompleteResult | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showShareModal, setShowShareModal] = useState(false);
  const [modalType, setModalType] = useState<'download' | 'share'>('download');

  useEffect(() => {
    // Carregar respostas do localStorage e calcular resultados
    const savedAnswers = localStorage.getItem("prudencia-answers");
    if (savedAnswers) {
      const answers = JSON.parse(savedAnswers);
      const completeResult = gerarResultadoCompleto(answers);
      setResult(completeResult);
    }
    setIsLoading(false);
  }, []);

  const handleDownload = () => {
    setModalType('download');
    setShowShareModal(true);
  };

  const handleShare = () => {
    setModalType('share');
    setShowShareModal(true);
  };

  const handleRetakeTest = () => {
    // Limpar todas as respostas do localStorage
    localStorage.removeItem("prudencia-answers");
    localStorage.removeItem("prudencia-current-question");
    // Redirecionar para o questionário
    window.location.href = "/questionario";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-lg text-muted-foreground">Analisando seus padrões de decisão...</p>
        </div>
      </div>
    );
  }

  if (!result) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Nenhum resultado encontrado.</p>
            <Button asChild>
              <Link href="/questionario">Fazer Teste</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Dados para os gráficos
  const radarData = [
    { subject: "Reflexão", A: result.pontuacoes.reflexao, fullMark: 50 },
    { subject: "Juízo", A: result.pontuacoes.juizo, fullMark: 50 },
    { subject: "Decisão", A: result.pontuacoes.decisao, fullMark: 50 }
  ];

  const barData = [
    { name: "Reflexão", pontuacao: result.pontuacoes.reflexao, ideal: 40 },
    { name: "Juízo", pontuacao: result.pontuacoes.juizo, ideal: 40 },
    { name: "Decisão", pontuacao: result.pontuacoes.decisao, ideal: 40 }
  ];

  const pieData = [
    { name: "Reflexão", value: result.pontuacoes.reflexao, color: "#8B7355" },
    { name: "Juízo", value: result.pontuacoes.juizo, color: "#A0956B" },
    { name: "Decisão", value: result.pontuacoes.decisao, color: "#6B5B47" }
  ];

  // Dados para gráfico de evolução (projeção de 15 dias)
  const evolutionData = [
    { dia: "Hoje", atual: result.pontuacoes.total / 3, potencial: result.pontuacoes.total / 3 },
    { dia: "Dia 5", atual: null, potencial: Math.min(50, (result.pontuacoes.total / 3) + 5) },
    { dia: "Dia 10", atual: null, potencial: Math.min(50, (result.pontuacoes.total / 3) + 8) },
    { dia: "Dia 15", atual: null, potencial: Math.min(50, (result.pontuacoes.total / 3) + 12) }
  ];

  const mediaGeral = Math.round((result.pontuacoes.total / 3) * 10) / 10;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-serif font-semibold text-foreground">
                Teste de Prudência
              </h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="w-4 h-4 mr-2" />
                Baixar PDF
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4 mr-2" />
                Compartilhar
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-7xl px-4 py-8 space-y-12">
        {/* SEÇÃO 1 - Visão Geral */}
        <section className="text-center space-y-8">
          <div className="space-y-4">
            <Badge variant="secondary" className="text-lg px-4 py-2 rounded-full">
              {result.perfil.nome}
            </Badge>
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground">
              Seu Perfil de Decisor
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              {result.perfil.frase}
            </p>
          </div>

          {/* Score Geral Visual */}
          <div className="max-w-md mx-auto">
            <div className="relative">
              <div className="w-32 h-32 mx-auto relative">
                <div className="absolute inset-0 rounded-full border-8 border-border"></div>
                <div 
                  className="absolute inset-0 rounded-full border-8 border-transparent"
                  style={{
                    borderTopColor: result.nivelGeral.cor,
                    transform: `rotate(${(mediaGeral / 50) * 360 - 90}deg)`
                  }}
                ></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-foreground">{mediaGeral}</div>
                    <div className="text-sm text-muted-foreground">Média</div>
                  </div>
                </div>
              </div>
              <div className="text-center mt-4">
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-2xl">{result.nivelGeral.emoji}</span>
                  <span className="text-lg font-semibold" style={{ color: result.nivelGeral.cor }}>
                    {result.nivelGeral.nivel}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  {result.nivelGeral.descricao}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* SEÇÃO 2 - 4 Gráficos */}
        <section>
          <h2 className="text-3xl font-serif font-bold text-foreground text-center mb-8">
            Análise Visual
          </h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Gráfico Radar */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-foreground flex items-center space-x-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span>Perfil Completo</span>
                </CardTitle>
                <CardDescription>
                  Visão radar das suas três dimensões da prudência
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <RadarChart data={radarData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis angle={0} domain={[0, 50]} />
                    <Radar
                      name="Sua Pontuação"
                      dataKey="A"
                      stroke="#8B7355"
                      fill="#8B7355"
                      fillOpacity={0.3}
                      strokeWidth={2}
                    />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Gráfico de Barras */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-foreground flex items-center space-x-2">
                  <Scale className="w-5 h-5 text-primary" />
                  <span>Comparação com Ideal</span>
                </CardTitle>
                <CardDescription>
                  Suas pontuações vs. o padrão ideal (40 pontos)
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={barData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis domain={[0, 50]} />
                    <Bar dataKey="pontuacao" fill="#8B7355" name="Sua Pontuação" />
                    <Bar dataKey="ideal" fill="#E8E5DF" name="Ideal" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Gráfico Circular */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-foreground flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-primary" />
                  <span>Distribuição de Pontos</span>
                </CardTitle>
                <CardDescription>
                  Como seus pontos estão distribuídos entre as áreas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Gráfico de Evolução */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader>
                <CardTitle className="text-xl font-serif text-foreground flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5 text-primary" />
                  <span>Potencial de Crescimento</span>
                </CardTitle>
                <CardDescription>
                  Projeção de evolução em 15 dias de prática
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={evolutionData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="dia" />
                    <YAxis domain={[0, 50]} />
                    <Line 
                      type="monotone" 
                      dataKey="atual" 
                      stroke="#8B7355" 
                      strokeWidth={3}
                      dot={{ r: 6 }}
                      name="Nível Atual"
                    />
                    <Line 
                      type="monotone" 
                      dataKey="potencial" 
                      stroke="#8B8B47" 
                      strokeWidth={2}
                      strokeDasharray="5 5"
                      name="Potencial"
                    />
                    <Legend />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* SEÇÃO 3 - Análise Detalhada */}
        <section>
          <h2 className="text-3xl font-serif font-bold text-foreground text-center mb-8">
            Análise Detalhada
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Reflexão */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Brain className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-serif text-foreground">
                  Reflexão
                </CardTitle>
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-2xl">{result.analise.reflexao.classificacao.emoji}</span>
                  <span className="font-semibold" style={{ color: result.analise.reflexao.classificacao.cor }}>
                    {result.analise.reflexao.pontuacao} pts
                  </span>
                </div>
                <Badge variant="secondary" style={{ backgroundColor: result.analise.reflexao.classificacao.cor + '20', color: result.analise.reflexao.classificacao.cor }}>
                  {result.analise.reflexao.classificacao.nivel}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {result.analise.reflexao.descricao}
                </p>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Pontos Fortes:</h4>
                    <ul className="space-y-1">
                      {result.analise.reflexao.pontosFortes.map((ponto, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <Star className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                          <span>{ponto}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Oportunidades:</h4>
                    <ul className="space-y-1">
                      {result.analise.reflexao.oportunidades.map((oportunidade, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <div className="w-3 h-3 bg-primary rounded-full mt-0.5 flex-shrink-0"></div>
                          <span>{oportunidade}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="bg-secondary/20 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground italic">
                    <strong>Exemplo:</strong> {result.analise.reflexao.exemplo}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Juízo */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Scale className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-serif text-foreground">
                  Juízo
                </CardTitle>
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-2xl">{result.analise.juizo.classificacao.emoji}</span>
                  <span className="font-semibold" style={{ color: result.analise.juizo.classificacao.cor }}>
                    {result.analise.juizo.pontuacao} pts
                  </span>
                </div>
                <Badge variant="secondary" style={{ backgroundColor: result.analise.juizo.classificacao.cor + '20', color: result.analise.juizo.classificacao.cor }}>
                  {result.analise.juizo.classificacao.nivel}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {result.analise.juizo.descricao}
                </p>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Pontos Fortes:</h4>
                    <ul className="space-y-1">
                      {result.analise.juizo.pontosFortes.map((ponto, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <Star className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                          <span>{ponto}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Oportunidades:</h4>
                    <ul className="space-y-1">
                      {result.analise.juizo.oportunidades.map((oportunidade, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <div className="w-3 h-3 bg-primary rounded-full mt-0.5 flex-shrink-0"></div>
                          <span>{oportunidade}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="bg-secondary/20 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground italic">
                    <strong>Exemplo:</strong> {result.analise.juizo.exemplo}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Decisão */}
            <Card className="bg-card border-border/50 shadow-lg">
              <CardHeader className="text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-primary" />
                </div>
                <CardTitle className="text-xl font-serif text-foreground">
                  Decisão
                </CardTitle>
                <div className="flex items-center justify-center space-x-2">
                  <span className="text-2xl">{result.analise.decisao.classificacao.emoji}</span>
                  <span className="font-semibold" style={{ color: result.analise.decisao.classificacao.cor }}>
                    {result.analise.decisao.pontuacao} pts
                  </span>
                </div>
                <Badge variant="secondary" style={{ backgroundColor: result.analise.decisao.classificacao.cor + '20', color: result.analise.decisao.classificacao.cor }}>
                  {result.analise.decisao.classificacao.nivel}
                </Badge>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {result.analise.decisao.descricao}
                </p>
                
                <div className="space-y-3">
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Pontos Fortes:</h4>
                    <ul className="space-y-1">
                      {result.analise.decisao.pontosFortes.map((ponto, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <Star className="w-3 h-3 text-primary mt-0.5 flex-shrink-0" />
                          <span>{ponto}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-foreground text-sm mb-2">Oportunidades:</h4>
                    <ul className="space-y-1">
                      {result.analise.decisao.oportunidades.map((oportunidade, index) => (
                        <li key={index} className="text-xs text-muted-foreground flex items-start space-x-2">
                          <div className="w-3 h-3 bg-primary rounded-full mt-0.5 flex-shrink-0"></div>
                          <span>{oportunidade}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                
                <div className="bg-secondary/20 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground italic">
                    <strong>Exemplo:</strong> {result.analise.decisao.exemplo}
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* CTA Final */}
        <section className="text-center">
          <div className="bg-gradient-to-r from-primary to-secondary p-12 rounded-2xl shadow-2xl">
            <h2 className="text-3xl font-serif font-bold text-white mb-6">
              Continue Sua Jornada de Desenvolvimento
            </h2>
            <p className="text-xl text-primary-foreground/90 mb-8 max-w-2xl mx-auto">
              Transforme seus insights em ação concreta com um plano personalizado ou refaça o teste para acompanhar sua evolução
            </p>
            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center items-center">
              <Button asChild size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90 px-6 md:px-12 py-4 md:py-8 text-lg md:text-xl font-bold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 border-4 border-white/50">
                <Link href="/plano-acao">
                  <Award className="mr-2 md:mr-3 w-5 md:w-7 h-5 md:h-7" />
                  PLANO DE AÇÃO
                  <br />
                  <span className="text-xs md:text-sm font-normal">15 dias de exercícios</span>
                </Link>
              </Button>
              <Button onClick={handleRetakeTest} size="lg" variant="outline" className="border-4 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-6 md:px-12 py-4 md:py-8 text-lg md:text-xl font-bold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <RotateCcw className="mr-2 md:mr-3 w-5 md:w-7 h-5 md:h-7" />
                REFAZER TESTE
                <br />
                <span className="text-xs md:text-sm font-normal">Acompanhe sua evolução</span>
              </Button>
            </div>
          </div>
        </section>
      </div>
      
      {/* Footer */}
      <footer className="border-t border-border/50 bg-background py-6 px-4 mt-8">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">
                Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados
              </span>
            </div>
          </div>
        </div>
      </footer>
      
      <SimpleShareModal 
        isOpen={showShareModal} 
        onClose={() => setShowShareModal(false)}
        type={modalType}
      />
    </div>
  );
}
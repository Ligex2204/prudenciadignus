"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { ArrowLeft, ArrowRight, Brain, Scale, Target } from "lucide-react";
import { questions, blockInfo } from "@/lib/questions";
import Link from "next/link";

interface Answers {
  [key: number]: number;
}

export default function QuestionarioPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Answers>({});
  const [selectedValue, setSelectedValue] = useState<number | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const currentQ = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;
  const isFirstQuestion = currentQuestion === 0;
  const isLastQuestion = currentQuestion === questions.length - 1;

  // Carregar respostas salvas do localStorage
  useEffect(() => {
    const savedAnswers = localStorage.getItem("prudencia-answers");
    if (savedAnswers) {
      const parsed = JSON.parse(savedAnswers);
      setAnswers(parsed);
      
      // Encontrar a primeira pergunta sem resposta
      const firstUnanswered = questions.findIndex(q => !parsed[q.id]);
      if (firstUnanswered !== -1) {
        setCurrentQuestion(firstUnanswered);
      } else {
        setCurrentQuestion(questions.length - 1);
      }
    }
  }, []);

  // Salvar respostas no localStorage
  useEffect(() => {
    if (Object.keys(answers).length > 0) {
      localStorage.setItem("prudencia-answers", JSON.stringify(answers));
    }
  }, [answers]);

  // Atualizar valor selecionado quando mudar de pergunta
  useEffect(() => {
    setSelectedValue(answers[currentQ.id] || null);
  }, [currentQuestion, answers]);

  const handleAnswerChange = (value: string) => {
    const numValue = parseInt(value);
    setSelectedValue(numValue);
    
    // Salvar resposta imediatamente
    setAnswers(prev => ({
      ...prev,
      [currentQ.id]: numValue
    }));
  };

  const goToNext = () => {
    if (selectedValue === null) return;
    
    setIsTransitioning(true);
    setTimeout(() => {
      if (isLastQuestion) {
        // Finalizar questionário
        window.location.href = "/resultados";
      } else {
        setCurrentQuestion(prev => prev + 1);
        setIsTransitioning(false);
      }
    }, 100);
  };

  const goToPrevious = () => {
    if (isFirstQuestion) {
      window.location.href = "/orientacao";
      return;
    }
    
    setIsTransitioning(true);
    setTimeout(() => {
      setCurrentQuestion(prev => prev - 1);
      setIsTransitioning(false);
    }, 100);
  };

  const getBlockTransition = () => {
    const currentBlock = currentQ.block;
    const prevBlock = currentQuestion > 0 ? questions[currentQuestion - 1].block : null;
    
    if (prevBlock && prevBlock !== currentBlock) {
      return {
        show: true,
        from: blockInfo[prevBlock as keyof typeof blockInfo],
        to: blockInfo[currentBlock]
      };
    }
    return { show: false };
  };

  const blockTransition = getBlockTransition();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      {/* Header Fixo */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 fixed top-0 left-0 right-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-serif font-semibold text-foreground">
                Teste de Prudência
              </h1>
            </Link>
            
            <div className="flex items-center space-x-6">
              <div className="text-sm text-muted-foreground">
                Progresso: <span className="font-medium text-foreground">{Math.round(progress)}%</span>
              </div>
              <div className="w-32">
                <Progress value={progress} className="h-2" />
              </div>
              <div className="text-sm font-medium text-foreground">
                {currentQuestion + 1} de {questions.length}
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <div className="container mx-auto max-w-4xl px-4 pt-24 pb-12">
        {/* Card de Transição de Bloco */}
        {blockTransition.show && (
          <Card className="bg-gradient-to-r from-primary/10 to-secondary/10 border-border/50 shadow-lg mb-8">
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="text-3xl">{blockTransition.from?.icon}</div>
                  <div>
                    <h3 className="text-lg font-serif font-semibold text-foreground">
                      {blockTransition.from?.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {blockTransition.from?.description}
                    </p>
                  </div>
                </div>
                <ArrowRight className="w-6 h-6 text-primary" />
                <div className="flex items-center space-x-4">
                  <div className="text-3xl">{blockTransition.to?.icon}</div>
                  <div>
                    <h3 className="text-lg font-serif font-semibold text-foreground">
                      {blockTransition.to?.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {blockTransition.to?.description}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Card da Pergunta */}
        <Card className={`bg-card border-border/50 shadow-lg transition-all duration-100 ${isTransitioning ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
          <CardHeader className="text-center pb-4 md:pb-6">
            <div className="flex items-center justify-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center">
                <span className="text-2xl">{blockInfo[currentQ.block].icon}</span>
              </div>
              <div>
                <CardTitle className="text-lg font-serif text-primary">
                  {blockInfo[currentQ.block].title}
                </CardTitle>
                <CardDescription className="text-sm">
                  {blockInfo[currentQ.block].description}
                </CardDescription>
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-serif font-semibold text-foreground">
                Pergunta {currentQuestion + 1} de {questions.length}
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                {currentQ.text}
              </p>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-4 md:space-y-8">
            {/* Opções de Resposta */}
            <RadioGroup
              value={selectedValue?.toString() || ""}
              onValueChange={handleAnswerChange}
              className="grid grid-cols-1 md:grid-cols-5 gap-2 md:gap-4"
            >
              {[1, 2, 3, 4, 5].map((value) => (
                <div key={value} className="text-center">
                  <RadioGroupItem
                    value={value.toString()}
                    id={`option-${value}`}
                    className="sr-only"
                  />
                  <Label
                    htmlFor={`option-${value}`}
                    className={`cursor-pointer transition-all duration-200 ${
                      selectedValue === value
                        ? "bg-primary text-primary-foreground scale-105 shadow-lg"
                        : "bg-secondary/50 hover:bg-secondary text-muted-foreground hover:text-foreground"
                    } rounded-xl p-4 md:p-6 block border-2 border-transparent hover:border-primary/30`}
                  >
                    <div className="space-y-1 md:space-y-2">
                      <span className="text-2xl md:text-3xl font-bold block">{value}</span>
                      <span className="text-xs md:text-sm font-medium">
                        {value === 1 && "Nunca"}
                        {value === 2 && "Raramente"}
                        {value === 3 && "Às vezes"}
                        {value === 4 && "Frequentemente"}
                        {value === 5 && "Sempre"}
                      </span>
                    </div>
                  </Label>
                </div>
              ))}
            </RadioGroup>

            {/* Botões de Navegação */}
            <div className="flex justify-between items-center pt-4 md:pt-6">
              <Button
                variant="outline"
                onClick={goToPrevious}
                className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground px-4 md:px-6 py-2 md:py-3 rounded-xl"
              >
                <ArrowLeft className="mr-2 w-4 h-4" />
                {isFirstQuestion ? "Voltar" : "Anterior"}
              </Button>
              
              <Button
                onClick={goToNext}
                disabled={selectedValue === null}
                className="bg-primary hover:bg-primary/90 text-primary-foreground px-6 md:px-8 py-2 md:py-3 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLastQuestion ? "Ver Resultados" : "Próxima"}
                {!isLastQuestion && <ArrowRight className="ml-2 w-4 h-4" />}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Informações Adicionais */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Suas respostas estão sendo salvas automaticamente. Você pode pausar e retomar quando quiser.
          </p>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="border-t border-border/50 bg-background py-6 px-4 mt-8">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">
                Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
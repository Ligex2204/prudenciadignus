"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, Brain, Scale, Target, Clock } from "lucide-react";
import Link from "next/link";

export default function OrientacaoPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-secondary/10">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-5 h-5 text-primary-foreground" />
              </div>
              <h1 className="text-xl font-serif font-semibold text-foreground">
                Teste de Prudência
              </h1>
            </Link>
            <div className="flex items-center space-x-4">
              <div className="text-sm text-muted-foreground">
                Progresso: <span className="font-medium text-foreground">0%</span>
              </div>
              <div className="w-24">
                <Progress value={0} className="h-2" />
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto max-w-4xl px-4 py-8">
        {/* Título Principal */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-6">
            Prepare-se para o Teste
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Este não é um teste de certo ou errado, mas um espelho de como você toma decisões. 
            Seja honesto consigo mesmo.
          </p>
        </div>

        {/* Cards Explicativos */}
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <Card className="bg-card border-border/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 rounded-xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-xl font-serif text-foreground">
                1. REFLEXÃO
              </CardTitle>
              <CardDescription className="text-sm font-medium text-primary">
                10 questões
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base text-muted-foreground leading-relaxed">
                Sua capacidade de observar, ponderar e considerar diferentes aspectos antes de formar uma opinião
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-card border-border/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 rounded-xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Scale className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-xl font-serif text-foreground">
                2. JUÍZO
              </CardTitle>
              <CardDescription className="text-sm font-medium text-primary">
                10 questões
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base text-muted-foreground leading-relaxed">
                Sua capacidade de avaliar com clareza, discernir o que é importante e formar opiniões fundamentadas
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-card border-border/50 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 rounded-xl">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="w-8 h-8 text-primary" />
              </div>
              <CardTitle className="text-xl font-serif text-foreground">
                3. DECISÃO
              </CardTitle>
              <CardDescription className="text-sm font-medium text-primary">
                10 questões
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base text-muted-foreground leading-relaxed">
                Sua capacidade de agir com firmeza, comprometer-se com suas escolhas e colocar decisões em prática
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Escala Visual */}
        <Card className="bg-card border-border/50 shadow-lg mb-8">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-serif text-foreground mb-2">
              Como Responder
            </CardTitle>
            <CardDescription className="text-lg text-muted-foreground">
              Para cada situação, avalie a frequência com que você age dessa forma
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 md:gap-6 max-w-3xl mx-auto">
              {[1, 2, 3, 4, 5].map((num) => (
                <div key={num} className="text-center">
                  <div className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-2 md:mb-3 rounded-full border-2 border-primary flex items-center justify-center bg-primary/5 hover:bg-primary/10 transition-colors">
                    <span className="text-xl md:text-2xl font-bold text-primary">{num}</span>
                  </div>
                  <div className="space-y-1">
                    <p className="font-semibold text-foreground text-sm md:text-base">
                      {num === 1 && "Nunca"}
                      {num === 2 && "Raramente"}
                      {num === 3 && "Às vezes"}
                      {num === 4 && "Frequentemente"}
                      {num === 5 && "Sempre"}
                    </p>
                    <p className="text-xs md:text-sm text-muted-foreground leading-tight">
                      {num === 1 && "Quase nunca faço isso"}
                      {num === 2 && "Raramente faço isso"}
                      {num === 3 && "Faço às vezes"}
                      {num === 4 && "Costumo fazer isso"}
                      {num === 5 && "Faço sempre"}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Informações Importantes */}
        <Card className="bg-secondary/5 border-border/50 mb-8">
          <CardContent className="pt-6">
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <div className="space-y-3">
                <h3 className="text-lg font-serif font-semibold text-foreground">
                  Antes de Começar
                </h3>
                <ul className="space-y-2 text-muted-foreground">
                  <li className="flex items-start space-x-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    <span>Reserve um ambiente tranquilo e sem distrações</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    <span>O teste leva aproximadamente 15 minutos para completar</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    <span>Suas respostas são salvas automaticamente</span>
                  </li>
                  <li className="flex items-start space-x-2">
                    <span className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></span>
                    <span>Seja sincero(a) - não há respostas certas ou erradas</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Principal */}
        <div className="text-center">
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-12 py-6 text-lg font-medium rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
            <Link href="/questionario">
              Começar o Teste
              <ArrowRight className="ml-2 w-5 h-5" />
            </Link>
          </Button>
          <p className="mt-4 text-sm text-muted-foreground">
            Você pode pausar e retomar quando quiser
          </p>
        </div>
      </div>
      
      {/* Footer */}
      <footer className="border-t border-border/50 bg-background py-6 px-4 mt-8">
        <div className="container mx-auto max-w-6xl">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-6 h-6 bg-primary rounded-full flex items-center justify-center">
                <Brain className="w-4 h-4 text-primary-foreground" />
              </div>
              <span className="text-sm text-muted-foreground">
                Feito por EduCriação para Grupo Virtus - 2025 Todos os direitos reservados
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
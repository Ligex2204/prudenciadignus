import type { Metadata } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const playfairDisplay = Playfair_Display({
  variable: "--font-playfair-display",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Teste de Prudência - Descubra seu Perfil de Decisor",
  description: "Avaliação interativa da virtude da prudência baseada na filosofia aristotélica e tomista. Descubra seu perfil de decisor e receba um plano personalizado de desenvolvimento.",
  keywords: ["prudência", "filosofia", "aristóteles", "tomista", "decisão", "autoconhecimento", "virtude"],
  authors: [{ name: "Teste de Prudência" }],
  openGraph: {
    title: "Teste de Prudência - Descubra seu Perfil de Decisor",
    description: "Avaliação interativa da virtude da prudência com relatório personalizado e plano de ação de 15 dias.",
    url: "https://prudencia-test.com",
    siteName: "Teste de Prudência",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Teste de Prudência - Descubra seu Perfil de Decisor",
    description: "Avaliação interativa da virtude da prudência com relatório personalizado e plano de ação de 15 dias.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${playfairDisplay.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
